/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: localhost    Database: aankoopDB
-- ------------------------------------------------------
-- Server version	10.11.14-MariaDB-0+deb12u2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `aankoopDB`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `aankoopDB` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;

USE `aankoopDB`;

--
-- Table structure for table `aankopen`
--

DROP TABLE IF EXISTS `aankopen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `aankopen` (
  `aankoop_id` int(11) NOT NULL AUTO_INCREMENT,
  `gebruiker_id` int(11) DEFAULT NULL,
  `winkel_id` int(11) DEFAULT NULL,
  `budget_id` int(11) DEFAULT NULL,
  `product` varchar(100) NOT NULL,
  `beschrijving` text DEFAULT NULL,
  `kostprijs` decimal(10,2) NOT NULL,
  `datum` date NOT NULL,
  PRIMARY KEY (`aankoop_id`),
  KEY `gebruiker_id` (`gebruiker_id`),
  KEY `winkel_id` (`winkel_id`),
  KEY `budget_id` (`budget_id`),
  CONSTRAINT `aankopen_ibfk_1` FOREIGN KEY (`gebruiker_id`) REFERENCES `gebruikers` (`gebruiker_id`),
  CONSTRAINT `aankopen_ibfk_2` FOREIGN KEY (`winkel_id`) REFERENCES `winkels` (`winkel_id`),
  CONSTRAINT `aankopen_ibfk_3` FOREIGN KEY (`budget_id`) REFERENCES `budgetten` (`budget_id`)
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aankopen`
--

LOCK TABLES `aankopen` WRITE;
/*!40000 ALTER TABLE `aankopen` DISABLE KEYS */;
INSERT INTO `aankopen` VALUES
(1,3,15,3,'Boss Katana-50 MkII','50W modeling versterker',249.00,'2025-11-03'),
(2,7,16,4,'ARCTIC Liquid Freezer III Pro','AIO CPU Koeler 360mm',106.04,'2025-11-27'),
(3,2,13,2,'Wintec 500 Veelzijdigheidszadel','Synthetisch zadel voor training',599.00,'2025-11-08'),
(4,5,16,4,'Samsung 980 PRO 2TB NVMe','PCIe 4.0 SSD',169.00,'2025-12-02'),
(5,1,11,1,'Petzl Sama Klimgordel','Lichtgewicht klimgordel',74.95,'2025-11-14'),
(6,6,16,4,'AMD Ryzen 9 7950X','16-Core Workstation CPU',549.00,'2025-11-05'),
(7,4,16,4,'Corsair Vengeance 32GB DDR5-6000','2x16GB RAM Kit',139.00,'2025-12-08'),
(8,3,4,3,'Fender Player Stratocaster','Elektrische gitaar - Polar White',799.00,'2025-11-02'),
(9,2,12,2,'Kerbl Poetskist Compleet','Complete verzorgingsset',45.50,'2025-11-19'),
(10,7,17,4,'Asus TUF GAMING X870-PLUS WIFI','ATX AM5 Motherboard',296.00,'2025-12-01'),
(11,1,12,1,'Metolius Chalk Bag + Chalk','Pofzak met magnesium pof',24.99,'2025-11-21'),
(12,5,8,4,'Intel Core i7-14700K','20-Core Gaming CPU',399.00,'2025-11-06'),
(13,3,5,3,'Boss DS-1 Distortion','Klassiek distortion pedaal',59.00,'2025-11-17'),
(14,6,2,5,'Lenovo ThinkPad T14 Gen 4','AMD Ryzen 7 PRO, 32GB RAM, 1TB SSD - Perfect voor Linux',1299.00,'2025-12-04'),
(15,2,14,2,'Harry\'s Horse Rijlaars Elite','Lederen rijlaarzen',189.99,'2025-11-11'),
(16,4,8,4,'Noctua NH-D15 chromax.black','Premium luchtkoeler',109.90,'2025-11-23'),
(17,7,8,4,'Samsung 990 Pro 4TB NVMe','M.2 PCIe 4.0 SSD',369.00,'2025-11-16'),
(18,1,11,1,'Black Diamond Momentum Klimschoenen','Comfortabele klimschoenen voor beginners',89.99,'2025-11-01'),
(19,3,19,3,'Apple Mac Mini M2 Pro','10-core CPU, 16GB RAM, 512GB SSD',1549.00,'2025-12-05'),
(20,6,8,4,'Corsair iCUE H150i Elite LCD','360mm AIO Koeler',299.95,'2025-11-12'),
(21,5,2,4,'Gigabyte Z790 AORUS ELITE AX','ATX LGA1700 Motherboard',269.00,'2025-11-28'),
(22,2,13,2,'Eskadron Heritage Zadeldek','Premium zadeldek',59.95,'2025-12-07'),
(23,4,2,4,'MSI MAG B650 TOMAHAWK WIFI','ATX AM5 Motherboard',219.00,'2025-11-09'),
(24,7,16,4,'Kingston FURY Beast 64GB DDR5-6000','2x32GB RAM Kit',689.00,'2025-11-25'),
(25,1,11,1,'Black Diamond Camalot Set','Professionele klim bescherming set',289.00,'2025-12-03'),
(26,3,4,3,'Ibanez Tube Screamer TS9','Overdrive effect pedaal',119.00,'2025-11-15'),
(27,6,16,4,'MSI MPG X670E Carbon WiFi','High-end AM5 Motherboard',399.00,'2025-11-20'),
(28,5,8,4,'G.Skill Ripjaws S5 32GB DDR5-6000','2x16GB RAM Kit',129.00,'2025-12-09'),
(29,2,12,2,'Uvex Suxxeed Velours Cap','Veiligheidshelm voor paardrijden',249.00,'2025-11-04'),
(30,7,17,4,'AMD Ryzen 7 9800X3D','8-Core Gaming Processor',429.98,'2025-11-18'),
(31,4,16,4,'AMD Ryzen 7 7800X3D','8-Core Gaming CPU',449.00,'2025-11-07'),
(32,1,11,1,'Ocun Crack Gloves','Handschoenen voor crack climbing',34.95,'2025-11-29'),
(33,3,15,3,'TC Electronic Hall of Fame 2','Reverb effect pedaal',149.00,'2025-12-06'),
(34,6,8,4,'G.Skill Trident Z5 RGB 64GB DDR5','2x32GB DDR5-6000',329.00,'2025-11-13'),
(35,5,16,4,'be quiet! Dark Rock Pro 5','Stille CPU koeler',99.90,'2025-11-22'),
(36,2,14,2,'Horze Spirit Halster + Teugels Set','Complete halster set',34.95,'2025-12-10'),
(37,7,16,4,'Asus ROG Astral RTX 5090 32GB','High-end grafische kaart',3149.00,'2025-11-26'),
(38,1,12,1,'Evolv Defy Bouldering Schoenen','Specifieke bouldering schoenen',99.99,'2025-11-10'),
(39,4,8,4,'WD Black SN850X 2TB NVMe','Gaming SSD',189.00,'2025-12-01'),
(40,3,5,3,'Ernie Ball Regular Slinky (5-pack)','Snaren voorraad',29.95,'2025-11-24'),
(41,6,2,4,'Samsung 990 Pro 2TB NVMe','Snelle M.2 SSD',189.00,'2025-12-08'),
(42,2,13,2,'LeMieux ProSport Brushing Boots','Beschermende beenbeschermers',89.00,'2025-11-16'),
(43,5,16,4,'Gigabyte GeForce RTX 4070 Ti SUPER','Gaming grafische kaart',899.00,'2025-11-30'),
(44,7,18,4,'Antec FLUX PRO ATX Case','Full Tower behuizing',187.95,'2025-12-04'),
(45,1,11,1,'Metolius Wood Grips Hangboard','Vingerboard voor thuistraining',79.95,'2025-11-19'),
(46,4,16,4,'MSI GeForce RTX 4080 SUPER','High-end grafische kaart',1249.00,'2025-11-05'),
(47,3,4,3,'Fender Deluxe Gig Bag','Stevige gitaartas',79.00,'2025-12-02'),
(48,6,16,4,'NVIDIA RTX 4070 Ti SUPER','Grafische kaart (goede Linux support)',899.00,'2025-11-28'),
(49,2,2,2,'Lenovo Legion Pro 5 Gaming Laptop','AMD Ryzen 7 7745HX, RTX 4070, 32GB RAM, 1TB SSD',1799.00,'2025-12-07'),
(50,5,2,4,'NZXT H7 Flow','ATX Mid Tower behuizing',149.95,'2025-11-14'),
(51,7,17,4,'Asus ROG STRIX 1200W Platinum PSU','Modulaire voeding',219.90,'2025-11-21'),
(52,1,2,1,'ASUS ROG Strix G16 Gaming Laptop','Intel i7-13650HX, RTX 4060, 16GB RAM, 1TB SSD',1599.00,'2025-12-09'),
(53,4,2,4,'Fractal Design Torrent Compact','ATX Mid Tower behuizing',189.95,'2025-11-03'),
(54,3,15,3,'Focusrite Scarlett 4i4 (4th Gen)','USB audio interface voor opnames',299.00,'2025-11-17'),
(55,6,3,5,'Red Hat Enterprise Linux Developer','1-jaar developer licentie',349.00,'2025-12-05'),
(56,5,8,4,'Seasonic Focus GX-850 850W Gold','Modulaire voeding',139.90,'2025-11-26'),
(57,2,20,6,'Raspberry Pi 5 8GB Complete Kit','Pi 5 met M.2 HAT, 512GB SSD, voeding',149.95,'2025-11-08'),
(58,7,20,6,'Raspberry Pi 5 8GB Developer Kit','Pi 5 met M.2 HAT, 1TB SSD, voeding',149.95,'2025-12-10'),
(59,1,20,6,'Raspberry Pi 5 8GB Starter Kit','Pi 5 met M.2 HAT, 512GB SSD, officiële voeding',149.95,'2025-11-12'),
(60,4,8,4,'Corsair RM850e 850W Gold','Modulaire voeding',129.90,'2025-11-20'),
(61,3,19,3,'Logic Pro (licentie)','Professionele DAW software',229.99,'2025-12-03'),
(62,6,3,5,'O\'Reilly Learning Platform (Jaar)','Online leerplatform tech',499.00,'2025-11-15'),
(63,5,20,6,'Raspberry Pi 5 8GB Starter Kit','Pi 5 met M.2 HAT, 512GB SSD, voeding',149.95,'2025-12-06'),
(64,3,15,3,'Audio-Technica ATH-M50x','Studio monitor hoofdtelefoon',149.00,'2025-11-23'),
(65,4,20,6,'Raspberry Pi 5 8GB Kit','Pi 5 met M.2 HAT, 512GB SSD, voeding',149.95,'2025-11-01'),
(66,6,20,6,'Raspberry Pi 5 8GB Developer Kit','Pi 5 met M.2 HAT, 1TB SSD, voeding',149.95,'2025-12-01'),
(67,6,20,6,'Raspberry Pi 5 8GB Server Kit','Extra Pi 5 voor Debian/Mint servers',149.95,'2025-11-09'),
(68,10,21,NULL,'ExodusCoffee','CoffeeBonen uit de zion gebergte prijs per kg',40.00,'2025-12-11'),
(69,6,16,5,'AMD RYZEN 9 9950 X3D','CPU om veel Virtuele computers te draaien met goede linux compabiliteit',650.00,'2025-12-11');
/*!40000 ALTER TABLE `aankopen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `budgetten`
--

DROP TABLE IF EXISTS `budgetten`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `budgetten` (
  `budget_id` int(11) NOT NULL AUTO_INCREMENT,
  `naam` varchar(50) NOT NULL,
  `beschrijving` text DEFAULT NULL,
  `jaartal` varchar(10) NOT NULL,
  `totaal_bedrag` decimal(12,2) NOT NULL,
  `opmerkingen` varchar(120) DEFAULT NULL,
  PRIMARY KEY (`budget_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `budgetten`
--

LOCK TABLES `budgetten` WRITE;
/*!40000 ALTER TABLE `budgetten` DISABLE KEYS */;
INSERT INTO `budgetten` VALUES
(1,'Klimsport','Budget voor klimmateriaal en boulderen','2025',3500.00,'Voor Rik - klimmen + gamelaptop'),
(2,'Paardensport','Budget voor paardrijden en accessoires','2025',6200.00,'Voor Vince - paarden + gamelaptop'),
(3,'Muziekapparatuur','Budget voor gitaren en audio equipment','2025',6500.00,'Voor Lisa - gitaren, Apple studio setup'),
(4,'PC Gaming & Building','Budget voor gaming PC componenten','2025',15000.03,'Voor Ben, Joel, Thiebe, Ludovic - PC builds'),
(5,'Linux & Software','Budget voor Linux systemen en software','2025',13000.00,'Voor Ludovic - Linux development + laptop'),
(6,'Raspberry Pi & IoT','Budget voor Raspberry Pi projecten','2025',1500.00,'Voor iedereen - Pi 5 projecten');
/*!40000 ALTER TABLE `budgetten` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gebruikers`
--

DROP TABLE IF EXISTS `gebruikers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `gebruikers` (
  `gebruiker_id` int(11) NOT NULL AUTO_INCREMENT,
  `naam` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `wachtwoord` varchar(255) NOT NULL,
  `is_admin` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`gebruiker_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gebruikers`
--

LOCK TABLES `gebruikers` WRITE;
/*!40000 ALTER TABLE `gebruikers` DISABLE KEYS */;
INSERT INTO `gebruikers` VALUES
(1,'rik','rik.braspenning@hgturnhout.be','braspenning',0),
(2,'vince','vince.geysen@hgturnhout.be','geysen',0),
(3,'lisa','yelisaveta.katcharian@hgturnhout.be','katcharian',0),
(4,'joel','joel.muanza@hgturnhout.be','muanza',0),
(5,'thiebe','thiebe.potters@hgturnhout.be','potters',0),
(6,'ludovic','ludovic.vandorpe@hgturnhout.be','vandorpe',0),
(7,'ben','ben.vannoten@hgturnhout.be','vannoten',0),
(8,'admin','admin@hgturnhout.be','moeskops',1),
(10,'Mr.moeskops','moeskops@heilig-graf.be','$2y$10$hGNlmPwlrQk8xLITzjanFeDUwz1PmjEKsDbPylbfevPk1edjXhjuu',1);
/*!40000 ALTER TABLE `gebruikers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `winkels`
--

DROP TABLE IF EXISTS `winkels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `winkels` (
  `winkel_id` int(11) NOT NULL AUTO_INCREMENT,
  `naam` varchar(100) NOT NULL,
  `beschrijving` text DEFAULT NULL,
  `adres` varchar(200) DEFAULT NULL,
  `telefoon` varchar(15) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `sterren` tinyint(4) DEFAULT NULL CHECK (`sterren` between 1 and 5),
  PRIMARY KEY (`winkel_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `winkels`
--

LOCK TABLES `winkels` WRITE;
/*!40000 ALTER TABLE `winkels` DISABLE KEYS */;
INSERT INTO `winkels` VALUES
(1,'MediaMarkt','Elektronicawinkel','Grote Markt 12','0123456789','info@mediamarkt.be',5),
(2,'Coolblue','Online elektronica winkel','Webshop','0112233445','support@coolblue.be',5),
(3,'Bol.com','Algemene online winkel','Webshop','0223456789','service@bol.com',4),
(4,'Bax Music','Muziekwinkel','Muziekstraat 5','0987654321','info@baxmusic.be',5),
(5,'Keymusic','Specialist in muziekinstrumenten','Hoofdstraat 3a','0133456789','contact@keymusic.be',4),
(6,'BikeParts Turnhout','Onderdelen voor motoren','Industrieweg 10','0145678901','sales@bikeparts.be',4),
(7,'BikeCenter Turnhout','Motorwinkel','Ringlaan 2','0147890123','info@bikecenter.be',5),
(8,'Alternate','IT en gaming producten','Technoweg 22','0151234567','info@alternate.be',5),
(9,'Arturia','Software synthesizers','Webshop','0122223333','support@arturia.com',4),
(10,'Auto5','Winkel voor auto- en motoronderhoud','Garageplein 4','0169876543','info@auto5.be',4),
(11,'A.S.Adventure Turnhout','Outdoor en klimmateriaal','Merodelei 110, 2300 Turnhout','014 43 21 80','turnhout@asadventure.com',5),
(12,'Decathlon Turnhout','Sport en outdoor winkel','Merodelei 234, 2300 Turnhout','014 47 02 90','turnhout@decathlon.be',4),
(13,'Horse Point','Online paardensport specialist','Webshop','015 50 12 34','info@horsepoint.be',5),
(14,'Equitack','Paardensport webshop België','Webshop','09 225 67 89','contact@equitack.be',5),
(15,'Thomann','Online muziekwinkel (DE)','Webshop','+4995462000','service@thomann.de',5),
(16,'Azerty','PC componenten specialist','Webshop','03 808 45 50','info@azerty.be',5),
(17,'Amazon Belgium','Online megastore','Webshop','0800 12 504','support@amazon.be',4),
(18,'Bytes At Work','IT hardware specialist','Webshop','016 24 08 00','sales@bytesatwork.be',4),
(19,'Apple Store Belgium','Apple producten en accessories','Webshop','0800 12 775','support@apple.be',5),
(20,'Tinytronics.be','Raspberry Pi en elektronica specialist','Webshop','0468 14 86 72','info@tinytronics.be',5),
(21,'Coffeeshopturnhout','Beste coffee bonen van de kempen','Markt2','031523151235','Cofeeshopturnhout@gov.be',5);
/*!40000 ALTER TABLE `winkels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'aankoopDB'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-03-03 11:26:04
