/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: localhost    Database: CoffeeShopTurnhout
-- ------------------------------------------------------
-- Server version	10.11.14-MariaDB-0+deb12u2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `CoffeeShopTurnhout`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `CoffeeShopTurnhout` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;

USE `CoffeeShopTurnhout`;

--
-- Table structure for table `leveranciers`
--

DROP TABLE IF EXISTS `leveranciers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `leveranciers` (
  `leverancier_id` int(11) NOT NULL AUTO_INCREMENT,
  `leverancier_naam` text NOT NULL,
  `leverancier_opslagplaats` text NOT NULL,
  `leverancier_plaats` text NOT NULL,
  `leverarancier_land` text NOT NULL,
  PRIMARY KEY (`leverancier_id`),
  UNIQUE KEY `leverancier_naam` (`leverancier_naam`) USING HASH
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leveranciers`
--

LOCK TABLES `leveranciers` WRITE;
/*!40000 ALTER TABLE `leveranciers` DISABLE KEYS */;
INSERT INTO `leveranciers` VALUES
(1,'Charlie&CoffeeCompanY','BaronDuFourStraat44','Turnhout','GrootBraband'),
(2,'Le café du braband','AlsembergseSteenweg1090','Ukkel','GrootBraband'),
(3,'Les trois Turcs','ArscottStraat32','SintJoost-TenNode','GrootBraband'),
(4,'De VlaamseLeeuwCoffee','Guldensporenstraat88','Kortrijk','West-Vlaanderen'),
(5,'De trage Coffee','Bochtlaan42','Genk','Groot Limburg'),
(6,'De meestoneconomischeMens coffee','BartDeWeverStraat67','Borgerhout','GrootBraband');
/*!40000 ALTER TABLE `leveranciers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_naam` text NOT NULL,
  `product_prijs` int(11) NOT NULL,
  `product_aantal` int(11) DEFAULT NULL,
  `leveraar_id` int(11) NOT NULL,
  PRIMARY KEY (`product_id`),
  UNIQUE KEY `product_naam` (`product_naam`) USING HASH
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES
(1,'ExodusCoffee',45,234,1),
(2,'Gelecoffee',2,230,4),
(3,'TukTukcoffee',5,23,3),
(4,'TweeEuroCoffee',2,42,6),
(5,'StrawberryMilkshakeCoffee',28,491,1),
(6,'L\'attomique',4,1241,2),
(7,'Le Lode',1,1,4),
(8,'LEL coffee',69,3,2),
(9,'C-MINE coffee',7,341,5),
(10,'Werhmachtcoffee',55,324,4),
(11,'WinterRingCoffee',5,234,5);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `owned_company_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `owned_company_id` (`owned_company_id`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`owned_company_id`) REFERENCES `leveranciers` (`leverancier_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'charlie','charlie@gmail.com','$2y$10$Wf7nUA/cMFDZLpFN/x6e4uDXOgmpxnrmO.BQbvYvJ5zDbBKwFX1S.',1,'2025-12-01 09:05:42'),
(2,'Filip','filip@gov.be','$2y$10$vpjtuE78HQUCGTlezIUBJ.Ymvc.7YTXzHQ/R8X/nA.9h0p4MAv10W',2,'2025-12-01 09:05:42'),
(3,'Saladman','saladman@telenet.com','$2y$10$HqVCWgHE4J8MTfLzpszRW.KWYPQaNlN.6uXyQnD/xksJQdyCBnA/S',3,'2025-12-01 09:05:42'),
(4,'TomGriekje','tomgriekje@dommestandpunten.be','$2y$10$9K77K3VUMdc0EZShVraFUOK5WyqjB2vFtp/ll9FLhoo7.2x5BW4.m',4,'2025-12-01 09:05:42'),
(5,'ZuhalDemir','zuhaldemir@vlaanderen-gov.be','$2y$10$k1yK7XarWMoGBqr8mB5hee/rYObXRy.QptRSi59/Y3TH/a/qbX4T6',5,'2025-12-01 09:05:42'),
(6,'Barttje','maximusdekat@federal-gov.be','$2y$10$jH.PICzpsVjWgTzMuBXhXO2NJ5xWKI.fI5KpUBm8DbdQc0GECe1ii',6,'2025-12-01 09:05:42');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'CoffeeShopTurnhout'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-03-03 11:26:04
