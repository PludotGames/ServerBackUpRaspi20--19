/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: localhost    Database: SportclubsDB
-- ------------------------------------------------------
-- Server version	10.11.14-MariaDB-0+deb12u2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `SportclubsDB`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `SportclubsDB` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;

USE `SportclubsDB`;

--
-- Table structure for table `clubs`
--

DROP TABLE IF EXISTS `clubs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `clubs` (
  `club_id` int(11) NOT NULL AUTO_INCREMENT,
  `naam` varchar(50) NOT NULL,
  `locatie` varchar(100) DEFAULT NULL,
  `sportsoort` varchar(50) DEFAULT NULL,
  `oprichtingsjaar` year(4) DEFAULT NULL,
  `aantal_leden` int(11) DEFAULT 0,
  PRIMARY KEY (`club_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clubs`
--

LOCK TABLES `clubs` WRITE;
/*!40000 ALTER TABLE `clubs` DISABLE KEYS */;
INSERT INTO `clubs` VALUES
(1,'Kempische Voetbalvereniging','Turnhout','Voetbal',1965,1),
(2,'Tennis Club Antwerpen','Antwerpen','Tennis',1980,1),
(3,'Volleybal Club Kempen','Geel','Volleybal',1975,1),
(4,'Kasterlee Schaatsvereniging','Kasterlee','Schaatsen',1990,7),
(5,'Basketbal Club Herentals','Herentals','Basketbal',1978,9),
(6,'Hockey Club Mol','Mol','Hockey',1985,5),
(7,'Badminton Club Lommel','Lommel','Badminton',2000,12),
(8,'Atletiek Vereniging Olen','Olen','Atletiek',1995,4),
(9,'Zwemclub Lier','Lier','Zwemmen',1983,6),
(10,'Rugby Club Mechelen','Mechelen','Rugby',1970,8),
(11,'Tafeltennis Club Balen','Balen','Tafeltennis',2002,4),
(12,'Judo Club Geel','Geel','Judo',1992,7),
(13,'Golf Club Beveren','Beveren','Golf',1987,5),
(14,'Handbal Club Arendonk','Arendonk','Handbal',1999,9),
(15,'Paardrijden Turnhout','Turnhout','Paardrijden',2001,5),
(16,'Gustaaf Klimt','Turnhout','Boulderen',2021,1100);
/*!40000 ALTER TABLE `clubs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `leden`
--

DROP TABLE IF EXISTS `leden`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `leden` (
  `lid_id` int(11) NOT NULL AUTO_INCREMENT,
  `naam` varchar(50) NOT NULL,
  `geboortedatum` date DEFAULT NULL,
  `geslacht` enum('M','V','Overig') DEFAULT 'Overig',
  `straat` varchar(100) DEFAULT NULL,
  `huisnummer` varchar(10) DEFAULT NULL,
  `postnummer` varchar(10) DEFAULT NULL,
  `plaats` varchar(100) DEFAULT NULL,
  `inschrijving` date DEFAULT NULL,
  `uitschrijving` date DEFAULT NULL,
  `club_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`lid_id`),
  KEY `club_id` (`club_id`),
  CONSTRAINT `leden_ibfk_1` FOREIGN KEY (`club_id`) REFERENCES `clubs` (`club_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leden`
--

LOCK TABLES `leden` WRITE;
/*!40000 ALTER TABLE `leden` DISABLE KEYS */;
INSERT INTO `leden` VALUES
(1,'Katrien De Vries','1987-03-25','V','Nieuwstraat','12','2300','Turnhout','2022-02-10',NULL,1),
(2,'Jan Vermeulen','1992-11-19','M','Gasthuisstraat','35','2300','Turnhout','2021-08-23',NULL,3),
(3,'Sofie Van Hoof','1985-07-17','V','Bloemenlaan','7','2300','Turnhout','2023-01-15',NULL,2);
/*!40000 ALTER TABLE `leden` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'SportclubsDB'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-03-03 11:26:04
