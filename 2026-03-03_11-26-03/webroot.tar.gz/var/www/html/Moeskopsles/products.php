<?php
if(session_status() === PHP_SESSION_NONE){
	session_start();
}

	ini_set('display_errors', 1);
	ini_set('display_startup_errors', 1);
	error_reporting(E_ALL);
	
	require_once "config.php";
	$is_logged_in = isset($_SESSION["user_id"]);
	if(!$is_logged_in){
			header("Location: index.php");
	}
	$succes = '';
	if (isset($_COOKIE['success_msg'])) {
		$succes = $_COOKIE['success_msg'];
		// Delete the cookie immediately so it shows only once
		setcookie('success_msg', '', time() - 3600, "/");
	}
	
	//retrieve all users products
	$conn = getDBconnection();
	$sql = "SELECT p.product_id , p.product_naam , p.product_prijs, p.product_aantal FROM products p JOIN leveranciers l ON p.leveraar_id = l.leverancier_id JOIN users u ON   u.owned_company_id = l.leverancier_id WHERE u.id = ?;";
	
	
	$stmt= $conn->prepare($sql);
	$stmt->bind_param("i", $_SESSION["user_id"]);
	$stmt->execute();
	$result = $stmt->get_result();
	$stmt->close();
	$conn->close();
	
	
	
?>
<!DOCTYPE html>
<html lang="nl">
<head>
	<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css" rel="stylesheet">
	<style>
		body {
			background-color: #2D5E65;
			margin-top: 200px;
			
		}
	
	</style>

</head>
<body>
	<?php include "navbar.php"; ?>
	<?php if (!empty($succes)) : ?>
		<div class="alert alert-success alert-dismissible fade show" role="alert">
			<?= htmlspecialchars($succes) ?>
			<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
		</div>
		
	<?php endif; ?>

	
	<div class="row justify-content-center g-4">
	<?php if ($result->num_rows > 0): ?>
            <?php while ($row = $result->fetch_assoc()): ?>
            
                <div class="col-12 col-sm-6 col-md-4 col-lg-3 d-flex">
                    <div class="card h-100 shadow-sm w-100">

                        

                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title"><?= htmlspecialchars($row['product_naam']); ?></h5>

                            <p><strong>Prijs:</strong> €<?= number_format($row['product_prijs'], 2, ',', '.'); ?></p>
                            <p><strong>Voorraad:</strong> <?= $row['product_aantal'] ?? 0; ?></p>

                            <p class="text-muted small">
                                <strong>ID:</strong> <?= htmlspecialchars($row['product_id']); ?>
                            </p>
							<div class="d-flex gap-2 mt-auto flex-column">
                            <a href="product_aanpassen.php?id=<?= $row['product_id']; ?>" 
                                class="btn btn-primary mt-auto btn-succes">
                                aanpassen
                            </a>
                            <a href="verwijder_product.php?id=<?= $row['product_id']; ?>" 
                                class="btn btn-primary mt-auto btn-danger">
                                Verwijderen
                            </a>
                            </div>
                        </div>

                    </div>
                </div>
			
            <?php endwhile; ?>
            <div class="col-12 col-sm-6 col-md-4 col-lg-3 d-flex">
                    <div class="card h-100 shadow-sm w-100">

                        

                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title text-center ">Product Toevoegen</h5>

                      

                            <a href="product_toevoegen.php" 
                                class="btn btn-primary mt-auto btn-succes">
                                Product toevoegen
                            </a>
                        </div>

                    </div>
                </div>
        <?php else: ?>
            <p class="text-center">Geen producten beschikbaar.</p>
        <?php endif; ?>
        </div>
	
	
	

	<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>

</body>
<footer>

</footer>
</html>
