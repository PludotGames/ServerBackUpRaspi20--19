<?php	
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
require_once 'config.php';

if($_SERVER['REQUEST_METHOD'] == 'POST'){
	$username_or_email = trim($_POST['username']) ?? "";
	$password = $_POST['password'] ?? "";
	
	$conn = getDBConnection();
	
	$stmt = $conn->prepare("SELECT id, username, email, password_hash FROM users WHERE username = ? OR email = ?;");
	$stmt->bind_param("ss", $username_or_email, $username_or_email);
	$stmt->execute();
	$result = $stmt->get_result();
	
	if($result->num_rows === 1){
		$user = $result->fetch_assoc();
		
		if(password_verify($password, $user['password_hash'])){
			$_SESSION['user_id'] = $user['id'];
			$_SESSION['username'] = $user['username'];
			
			header("location: index.php");
			exit();
		}else{
			$_SESSION['login_errors'] = ["Wachtwoord onjuist"];
		}
	}else{
		 $_SESSION['login_errors'] = ["Gebruiker niet gevonden"];
	}
	$stmt->close();
	$conn->close();
	header("Location: index.php");
    exit();
}
?>
