<?php
// Destroy all cookies
foreach ($_COOKIE as $key => $value) {
    setcookie($key, '', time() - 3600, '/'); // Expire each cookie
}

// Optional: destroy session
session_start();
session_unset();
session_destroy();

// Refresh or redirect to homepage
header("Location: index.php"); 
exit;
?>
