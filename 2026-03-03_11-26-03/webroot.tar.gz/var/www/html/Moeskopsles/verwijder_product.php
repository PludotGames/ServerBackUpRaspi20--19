<?php 
$product_id = $_GET["id"];
require_once 'config.php';

$conn = getDBConnection();

$sql = "DELETE FROM products WHERE product_id = ?;";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $product_id);
if($stmt->execute()){
	$stmt->close();
	$conn->close();
	setcookie("success_msg", "Product succesvol verwijderd!", time() + 10, "/");
	header("Location: products.php");
	exit;

}else{
	$stmt->close();
	$conn->close();
	header("Location: products.php");
	exit;
}
	
	

?>

