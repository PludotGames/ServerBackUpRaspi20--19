CREATE DATABASE IF NOT EXISTS CoffeeShopTurnhout;

USE CoffeeShopTurnhout;


CREATE TABLE IF NOT EXISTS  leveranciers (
    leverancier_id INT AUTO_INCREMENT PRIMARY KEY,
    leverancier_naam TEXT UNIQUE NOT NULL,
    leverancier_opslagplaats TEXT NOT NULL ,
    leverancier_plaats TEXT NOT NULL,
    leverarancier_land TEXT NOT NULL
);

CREATE TABLE iF NOT EXISTS products (
  product_id INT AUTO_INCREMENT PRIMARY KEY,
  product_naam TEXT UNIQUE NOT NULL,
  product_prijs INT NOT NULL,
  product_aantal INT,
  leveraar_id INT NOT NULL
  
);

CREATE TABLE IF NOT EXISTS  users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    owned_company_id INT,
    FOREIGN KEY (owned_company_id) REFERENCES leveranciers(leverancier_id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    
    
);



INSERT INTO leveranciers(leverancier_id ,leverancier_naam, leverancier_opslagplaats, leverancier_plaats, leverarancier_land)
VALUES
    (1,"Charlie&CoffeeCompanY", "BaronDuFourStraat44", "Turnhout", "GrootBraband"),
    (2,"Le café du braband", "AlsembergseSteenweg1090", "Ukkel", "GrootBraband"),
    (3,"Les trois Turcs", "ArscottStraat32", "SintJoost-TenNode", "GrootBraband"),
    (4,"De VlaamseLeeuwCoffee", "Guldensporenstraat88", "Kortrijk", "West-Vlaanderen"),
    (5,"De trage Coffee", "Bochtlaan42", "Genk", "Groot Limburg"),
    (6,"De meestoneconomischeMens coffee", "BartDeWeverStraat67", "Borgerhout", "GrootBraband");

INSERT INTO products(product_naam,product_prijs,product_aantal,leveraar_id) VALUES
    ("ExodusCoffee", 45 , 234 , 1),
    ("Gelecoffee" , 2.40 , 230 , 4),
    ("TukTukcoffee", 5 , 23, 3),
    ("TweeEuroCoffee", 2 , 42 , 6),
    ("StrawberryMilkshakeCoffee" , 28, 491, 1),
    ("L'attomique",3.50, 1241, 2),
    ("Le Lode", 0.60 , 1 , 4),
    ("LEL coffee",69,3,2 ),
    ("C-MINE coffee", 6.50, 341 , 5),
    ("Werhmachtcoffee", 55 , 324, 4 ),
    ("WinterRingCoffee", 4.50 , 234 , 5);
   
INSERT INTO users(username, email, password_hash, owned_company_id) VALUES
	("charlie", "charlie@gmail.com", "$2y$10$Wf7nUA/cMFDZLpFN/x6e4uDXOgmpxnrmO.BQbvYvJ5zDbBKwFX1S.",1),
	("Filip","filip@gov.be","$2y$10$vpjtuE78HQUCGTlezIUBJ.Ymvc.7YTXzHQ/R8X/nA.9h0p4MAv10W",2),
	("Saladman","saladman@telenet.com","$2y$10$HqVCWgHE4J8MTfLzpszRW.KWYPQaNlN.6uXyQnD/xksJQdyCBnA/S",3),
	("TomGriekje","tomgriekje@dommestandpunten.be","$2y$10$9K77K3VUMdc0EZShVraFUOK5WyqjB2vFtp/ll9FLhoo7.2x5BW4.m",4),
	("ZuhalDemir","zuhaldemir@vlaanderen-gov.be","$2y$10$k1yK7XarWMoGBqr8mB5hee/rYObXRy.QptRSi59/Y3TH/a/qbX4T6",5),
	("Barttje","maximusdekat@federal-gov.be","$2y$10$jH.PICzpsVjWgTzMuBXhXO2NJ5xWKI.fI5KpUBm8DbdQc0GECe1ii",6);
