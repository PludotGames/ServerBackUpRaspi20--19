<?php 
if(session_status() == PHP_SESSION_NONE){
	session_start();
}
	ini_set('display_errors', 1);
	ini_set('display_startup_errors', 1);
	error_reporting(E_ALL);

	require_once "config.php";
	$is_logged_in = isset($_SESSION['user_id']);
	if(!$is_logged_in){
		header("Location: index.php");
	}
	$succes = '';
	if (isset($_COOKIE['success_msg'])) {
		$succes = $_COOKIE['success_msg'];
		// Delete the cookie immediately so it shows only once
		setcookie('success_msg', '', time() - 3600, "/");
	}
	
	$conn = getDBConnection();
	
	$sql = "SELECT u.username, l.leverancier_naam, l.leverancier_opslagplaats, l.leverancier_plaats, l.leverarancier_land  FROM users u JOIN leveranciers l ON u.owned_company_id = l.leverancier_id;";
	
	$stmt = $conn->prepare($sql);
	$stmt->execute();
	$stmt->bind_result($username,$company,$company_loc,$company_region,$company_country);
	
	if($stmt->fetch()){
		
	}else{
		$username = "geen gevonden";
		$company = "geen gevonden";
	}
	$stmt->close();
	$conn->close();

	if($_SERVER["REQUEST_METHOD"]=== "POST"){
	
		if($_POST["action"] === "passwordchange"){
			$newpassword = $_POST['newpassword'];
			
			
			//kijken of het nieuw wachtwoord gelijk zijn aan elkaar
			$conn = getDBConnection();
			$sql ="SELECT password_hash FROM users WHERE id = ? ;";
			$stmt = $conn->prepare($sql);
			$stmt->bind_param("i", $_SESSION["user_id"]);
			$stmt->execute();
			$stmt->bind_result($existing_hash);
			$stmt->fetch();
			$stmt->close();
			
			if(!isset($error)){
				$newhash = password_hash($newpassword, PASSWORD_DEFAULT);
				
				if(password_verify($newpassword, $existing_hash)){
					$error = "Onveranderd Wachtwoord";
				}else{
					$sql = "UPDATE users SET password_hash = ? WHERE id = ?;";
					$update = $conn->prepare($sql);
					$update->bind_param("si", $newhash, $_SESSION["user_id"]);
					
					if($update->execute()){
						setcookie("success_msg", "Passwoord succesvol veranderd", time() + 10, "/");
						header("Location: profiel.php");
						
					}else{
						$error = "Er ging iets mis";
					}
					
					$update->close();
				}
				
			}
			$conn->close();
		}else if($_POST["action"]==="companydatachange"){
			$newcompanyname = $_POST["company_naam"];
			$newcompanyaddress = $_POST["address"];
			$newcompanyregion = $_POST["Regio"];
			$newcompanycountry = $_POST["land"];
			
			$conn = getDBConnection();
			$sql = "UPDATE leveranciers AS l JOIN users AS u ON u.owned_company_id = l.leverancier_id SET l.leverancier_naam = ?, l.leverancier_opslagplaats = ?, l.leverancier_plaats = ?, l.leverarancier_land = ? WHERE u.id = ?;";	
			$update = $conn->prepare($sql);
			$update->bind_param("ssssi", $newcompanyname, $newcompanyaddress, $newcompanyregion, $newcompanycountry, $_SESSION["user_id"]);
			if($update->execute()){
				setcookie("success_msg", "bedrijf succesvol aangepast!", time() + 10, "/");
				header("Location: profiel.php");
				
			}
			
			$update->close();
			$conn->close();
		}
		
	}
?>
<!DOCTYPE html>
<html>

<head>
	<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css" rel="stylesheet">
	<style>
		body {
			background-color: #2D5E65;
			margin-top: 50px;
		}
	
	</style>
</head>

<body>
<?php include "navbar.php"?>

  <div class="container py-5">
	<?php if (!empty($succes)) : ?>
		<div class="alert alert-success alert-dismissible fade show" role="alert">
			<?= htmlspecialchars($succes) ?>
			<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
		</div>
	<?php endif; ?>
	<?php if (!empty($error)) : ?>
		<div class="alert alert-danger">
			<?= htmlspecialchars($error) ?>
		</div>
	<?php endif; ?>
    <div class="card shadow-lg p-4">
      <h2 class="mb-4 text-center">User Information</h2>

      <form method="POST" action="">

        <!-- Username -->
        <div class="mb-3">
          <label class="form-label">Username</label>
          <input type="text" class="form-control" value="<?php echo htmlspecialchars($username); ?>" readonly id="newname" name="newname">
        </div>

        <!-- Password -->
        <div class="mb-3">
          <label class="form-label">Password (modify)</label>
          <input type="password" class="form-control" placeholder="voeg in een nieuw wachtwoord" id="newpassword" name="newpassword">
			<div>
			<button class="btn btn-primary w-100 mt-3" name="action" value="passwordchange">Change Password</button>
			</div>
        </div>

        <!-- Company -->
        <div class="conainer">
			<h2> Bedrijk: <?php echo htmlspecialchars($company); ?></h2>
        <h5 class="mb-3">Bedrijfsgegevens</h5>

			<div class="mb-3">
				<label for="company_naam" class="form-label">Bedrijfsnaam *</label>
				<input type="text" class="form-control" id="company_naam" name="company_naam"
					   value="<?= $company ?? '' ?>" required>
			</div>

			<div class="row">
				<div class="col-md-8 mb-3">
					<label for="address" class="form-label">Adres *</label>
					<input type="text" class="form-control" id="address" name="address"
						   value="<?= $company_loc ?? '' ?>" required>
				</div>
				<div class="col-md-4 mb-3">
					<label for="house_number" class="form-label">Regio</label>
					<input type="text" class="form-control" id="regio" name="Regio"
						   value="<?= $company_region ?? '' ?>" required>
				</div>
			</div>

			<div class="row align-items-center">
				<div class="col-md-4 mb-3">
					<label for="postal_code" class="form-label">Land</label>
					<input type="text" class="form-control" id="land" name="land"
						   value="<?= $company_country?? '' ?>" required>
				</div>
				<div class="col-md-8 mb-3 mt-3">
					<button class="btn btn-primary btn-succes w-100 mt-3 " name="action" value="companydatachange">Wijzigen</button>
				</div>
			</div>
        <div>
        
        </div>
		</div>
        

      </form>
    </div>
  </div>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>

</body>

<footer>

</footer>

</html>


