<!DOCTYPE html>
<html>
<header>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
	
	<style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #2D5E65;
            min-height: 100vh;
            margin-top: 120px;
            padding: 40px 20px;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
        }

        h1 {
            text-align: center;
            color: white;
            margin-bottom: 40px;
            font-size: 2.5em;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.2);
        }

        .card-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 30px;
            margin-bottom: 50px;
        }

        .card {
            background: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            cursor: pointer;
            text-decoration: none;
            color: inherit;
            display: block;
        }

        .card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 40px rgba(0,0,0,0.4);
        }

        .card-image {
            width: 100%;
            height: 200px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 4em;
            color: white;
        }

        .card:nth-child(2) .card-image {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
        }

        .card:nth-child(3) .card-image {
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
        }

        .card:nth-child(4) .card-image {
            background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
        }

        .card-content {
            padding: 25px;
        }

        .card-title {
            font-size: 1.5em;
            margin-bottom: 10px;
            color: #333;
        }

        .card-description {
            color: #666;
            line-height: 1.6;
        }

        .text-box-section {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
        }

        .text-box-section h2 {
            margin-bottom: 20px;
            color: #333;
        }

        .text-box {
            width: 100%;
            min-height: 150px;
            padding: 15px;
            border: 2px solid #ddd;
            border-radius: 10px;
            font-size: 1em;
            font-family: inherit;
            resize: vertical;
            transition: border-color 0.3s ease;
        }

        .text-box:focus {
            outline: none;
            border-color: #667eea;
        }

        @media (max-width: 768px) {
            h1 {
                font-size: 2em;
            }

            .card-container {
                grid-template-columns: 1fr;
            }
        }
    </style>
</header>
<body>
	<?php 
	if(session_status() == PHP_SESSION_NONE){
	session_start();
	}

	$is_logged_in = isset($_SESSION['user_id']);
	if(!$is_logged_in){
		header("Location: index.php");
	}
	include "navbar.php";
	?>
	 <div class="container">
        <h1>Welkom bij de CoffeeShopTurnhout Leverancier portaal!</h1>
        
        <div class="card-container">
            <a href="index.php" class="card">
                <div class="card-image">🏠</div>
                <div class="card-content">
                    <h3 class="card-title">Home</h3>
                    <p class="card-description">Ga terug naar de hoofdpagina om als een ander gebruiken in te loggen</p>
                </div>
            </a>

            <a href="profiel.php" class="card">
                <div class="card-image">ℹ️</div>
                <div class="card-content">
                    <h3 class="card-title">Je profiel</h3>
                    <p class="card-description">Bekijk hier je profiel <br> -Wachtwoord en gebruikersnaam <br> -Je bedrijfgegevensweergave</p>
                </div>
            </a>

            <a href="products.php" class="card">
                <div class="card-image">&#128203;</div>
                <div class="card-content">
                    <h3 class="card-title">Producten overzicht</h3>
                    <p class="card-description">Voeg of verwijder producten uit jouw bedrijfs catalogus</p>
                </div>
            </a>
        </div>

        
    </div>
</body>
<footer>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" ></script>
</footer>
</html>
