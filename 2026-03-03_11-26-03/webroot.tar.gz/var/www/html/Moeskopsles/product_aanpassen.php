<?php
if(session_status() === PHP_SESSION_NONE){
	session_start();
}
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$product_id = $_GET['id'];
$user_id = $_SESSION["user_id"];
require_once "config.php";

$succes = '';
if (isset($_COOKIE['success_msg'])) {
    $succes = $_COOKIE['success_msg'];
    // Delete the cookie immediately so it shows only once
    setcookie('success_msg', '', time() - 3600, "/");
}


if($_SERVER["REQUEST_METHOD"]==="POST"){
	$nieuwnaam = $_POST["product_naam"];
	$nieuweprijs = $_POST["product_prijs"];
	$nieuwaantal = $_POST["product_aantal"];
	
	$sql ="UPDATE products SET product_naam = ?, product_prijs = ? , product_aantal = ? WHERE product_id = ?;";
	$conn = getDBConnection();
	$update = $conn->prepare($sql);
	$update->bind_param("siii", $nieuwnaam, $nieuweprijs, $nieuwaantal, $product_id);
	if($update->execute()){
		setcookie("success_msg", "Product succesvol aangepast!", time() + 10, "/");
		header("Location: product_aanpassen.php?id=" . urlencode($product_id));
	}else{
		$error = "Product niet aangepast";
		$sql="SELECT product_naam, product_prijs, product_aantal FROM products WHERE product_id = ?;";
	}
	$update->close();
	$conn->close();
	
}
$conn = getDBConnection();

$sql="SELECT product_naam, product_prijs, product_aantal FROM products WHERE product_id = ?;";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $product_id);
$stmt->execute();
$result = $stmt->get_result();
$stmt->close();
$conn->close();
$product = $result->fetch_assoc();
?>


<!DOCTYPE html>
<html lang="nl">
<head>
	<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css" rel="stylesheet">
	<style>
		body {
			background-color: #2D5E65;
			margin-top: 200px;
			
		}
	
	</style>

</head>	
<body>
<?php include"navbar.php" ?>
	<div class="container py-5">
		
		<?php if (!empty($succes)) : ?>
		<div class="alert alert-success alert-dismissible fade show" role="alert">
			<?= htmlspecialchars($succes) ?>
			<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
		</div>
		
		<?php endif; ?>

		<?php if (!empty($error)) : ?>
		<div class="alert alert-danger alert-dismissible fade show" role="alert">
			<?= htmlspecialchars($error) ?>
			<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
		</div>
		<?php endif; ?>
		<div class="card shadow-lg mx-auto" style="max-width: 800px;">
			<div class="card-header bg-primary text-white text-center">
				<h3>Product Aanpassen</h3>
			</div>
			<div class="card-body">
				<form method="post" action="">
					
					<!-- Product Name -->
					<div class="mb-3">
						<label for="productNaam" class="form-label">Product Naam</label>
						<input type="text" class="form-control" id="productNaam" name="product_naam" 
							value="<?= htmlspecialchars($product['product_naam']); ?>" required>
					</div>

					<!-- Product Price -->
					<div class="mb-3">
						<label for="productPrijs" class="form-label">Prijs (€)</label>
						<input type="number" step="0.01" class="form-control" id="productPrijs" name="product_prijs" 
							value="<?= htmlspecialchars($product['product_prijs']); ?>" required>
					</div>

					<!-- Product Quantity -->
					<div class="mb-3">
						<label for="productAantal" class="form-label">Voorraad</label>
						<input type="number" class="form-control" id="productAantal" name="product_aantal" 
							value="<?= htmlspecialchars($product['product_aantal']); ?>" required>
					</div>

					<!-- Submit buttons -->
					<div class="d-flex justify-content-between mt-4">
						<button type="submit" name="update_product" class="btn btn-success">
							Opslaan
						</button>
						<a href="products.php" class="btn btn-secondary">
							Annuleren
						</a>
					</div>

				</form>
			</div>
		</div>
	</div>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>
</body>
</html>



