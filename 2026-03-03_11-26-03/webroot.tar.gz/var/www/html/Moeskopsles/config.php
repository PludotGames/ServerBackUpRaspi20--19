<?php
//database configuration
define("DB_HOST", "localhost");
define("DB_USER", "coffeeshop");
define("DB_PASS", "coffee");
define("DB_NAME", "CoffeeShopTurnhout");

function getDBConnection()
{
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

    if ($conn->connect_error) {
        die("connection failed" . $conn->connect_error);
    }

    return $conn;
}
?>
