<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home - CoffeeShopTurnhout</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { padding-top: 56px; }
        .header-home {
            background: #2D5E65;
            color: #d2e1ec;
            padding: 60px 0;
            text-align: center;
        }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>

    <header class="header-home">
        <div class="container">
            <h1 class="display-3 fw-bold">Welkom bij de hoofdpagina van de CST</h1>
            <p class="lead mt-3">Hier vind je duizenden variaties van coffeebonen</p>
        </div>
    </header>

    <section class="py-5" style="min-height: calc(100vh - 56px - 240px);">
        <div class="container-fluid h-100">
            <div class="row h-100 g-0">
                <!-- Left Side - Leverancier Login -->
                <div class="col-md-6 d-flex align-items-center justify-content-center bg-light border-end" style="min-height: 500px;">
                    <div class="w-75" style="max-width: 400px;">
                        <h2 class="text-center mb-4">Leverancier Login</h2>
                        <p class="text-center text-muted mb-4">Log in om uw bestellingen te beheren</p>
                        <form method='post' action="login_process.php">
							<div class="mb-3">
								<label for="username" class="form-label">Gebruikersnaam</label>
								<input type="text" class="form-control" id="username" name="username" placeholder="Voer uw gebruikersnaam in" required>
							</div>
							<div class="mb-3">
								<label for="password" class="form-label">Wachtwoord</label>
								<input type="password" class="form-control" id="password" name="password" placeholder="Voer uw wachtwoord in" required>
							</div>
							<button type="submit" class="btn btn-primary w-100 mb-3">Inloggen</button>
							<div class="text-center">
								<a href="register.php" class="text-decoration-none small">Registreren als leverancier</a>
							</div>
						</form>
                    </div>
                </div>

                <!-- Right Side - Shop Access -->
                <div class="col-md-6 d-flex align-items-center justify-content-center" style="min-height: 500px; background: #2D5E65">
                    <div class="text-center text-white px-4">
                        <h2 class="display-4 fw-bold mb-4">Bezoek Onze Shop</h2>
                        <p class="lead mb-4">Ontdek ons volledige assortiment producten</p>
                        <a href="shop.php" class="btn btn-light btn-lg px-5">Ga Naar Shop</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>
</body>
</html>
