<?php
	require_once 'config.php';

	//get shop data to display
	
	$conn = getDBConnection();
	
	$sql = "
		SELECT
			p.product_id,
			p.product_naam,
			p.product_prijs,
			p.product_aantal,
			l.leverancier_naam
		FROM products p 
		JOIN leveranciers l
			ON p.leveraar_id = l.leverancier_id;
	";
	$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Shop – Producten</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css" rel="stylesheet">
    <style >
		body{
			background-color: #2D5E65;
			padding-top: 58px;
			margin-top: 40px;
		}
    </style>
    
</head>
<body>
<?php include 'navbar.php'?>

<div class="container py-5">
    <h1 class="mb-4 text-center">Onze Producten</h1>

    <div class="row g-4">
        <?php if ($result->num_rows > 0): ?>
            <?php while ($row = $result->fetch_assoc()): ?>
                <div class="col-md-4 col-lg-3">
                    <div class="card h-100 shadow-sm">

                        

                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title"><?= htmlspecialchars($row['product_naam']); ?></h5>

                            <p><strong>Prijs:</strong> €<?= number_format($row['product_prijs'], 2, ',', '.'); ?></p>
                            <p><strong>Voorraad:</strong> <?= $row['product_aantal'] ?? 0; ?></p>

                            <p class="text-muted small">
                                <strong>Leverancier:</strong> <?= htmlspecialchars($row['leverancier_naam']); ?>
                            </p>

                            <a href="product.php?id=<?= $row['product_id']; ?>" 
                                class="btn btn-primary mt-auto">
                                Bekijken
                            </a>
                        </div>

                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p class="text-center">Geen producten beschikbaar.</p>
        <?php endif; ?>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>
</body>
</html>

