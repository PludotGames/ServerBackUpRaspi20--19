<?php
if(session_status() == PHP_SESSION_NONE){
	session_start();
}


$current_page = basename($_SERVER["PHP_SELF"]);
$is_logged_in = isset($_SESSION['user_id']);
$username = $_SESSION['username'] ?? '';
?>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">CoffeeShopTurnhout
			<?php if ($is_logged_in): ?>
			- <?= htmlspecialchars($username) ?>
			<?php endif; ?>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link <?= ($current_page == 'index.php') ? 'active' : '' ?>" href="index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= ($current_page == 'shop.php') ? 'active' : '' ?>" href="shop.php">Shop – Producten</a>
                </li>
                <?php if($is_logged_in): ?>
                <li class="nav-item">
                    <a class="nav-link <?= ($current_page == 'leverancierportaal.php') ? 'active': '' ?>" href="leverancierportaal.php">!leverancierportaal!</a>
                </li>
                
               <li class="nav-item">
                    <a class="nav-link <?= ($current_page == 'profiel.php') ? 'active': '' ?>" href="profiel.php">!jouw profiel!</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= ($current_page == 'products.php') ? 'active': '' ?>" href="products.php">!Producten overzicht!</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="log_out.php">logout</a>
                </li>
                <?php endif;?>
            </ul>
        </div>
    </div>
</nav>
