<?php
// Enable PHP error output immediately
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
require_once "config.php";

$errors = $_SESSION['registration_errors'] ?? [];
$form_data = $_SESSION['form_data'] ?? [];

unset($_SESSION['registration_errors'], $_SESSION['form_data']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $conn = getDBConnection();

    // Collect data safely
    $username = trim($_POST['username'] ?? "");
    $email = trim($_POST['email'] ?? "");
    $password = $_POST['password'] ?? "";
    $confirm_password = $_POST['confirm_password'] ?? "";

    $leverancier_naam = trim($_POST['company_naam'] ?? "");
    $leverancier_opslagplaats = trim($_POST['address'] ?? "") . " " . trim($_POST['house_number'] ?? "");
    $leverancier_plaats = trim($_POST['city'] ?? "") . " " . trim($_POST['postal_code'] ?? "");
    $leverancier_land = trim($_POST['country'] ?? "");

    $errors = [];

    // Basic validation
    if (empty($username)) $errors[] = "Gebruikersnaam is verplicht.";
    if (empty($email)) $errors[] = "E-mailadres is verplicht.";
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = "Ongeldig e-mailadres.";

    if (strlen($password) < 8) $errors[] = "Wachtwoord moet minstens 8 karakters bevatten.";
    if ($password !== $confirm_password) $errors[] = "Wachtwoorden komen niet overeen.";

    if (empty($leverancier_naam)) $errors[] = "Bedrijfsnaam is verplicht.";

    // Username/email check
    $stmt = $conn->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
    $stmt->bind_param("ss", $username, $email);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $errors[] = "Gebruikersnaam of e-mailadres bestaat al.";
    }
    $stmt->close();

    // Company name check
    $stmt = $conn->prepare("SELECT leverancier_id FROM leveranciers WHERE leverancier_naam = ?");
    $stmt->bind_param("s", $leverancier_naam);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $errors[] = "Bedrijfsnaam bestaat al.";
    }
    $stmt->close();

    // If there are errors → return to form
    if (!empty($errors)) {
        $_SESSION['registration_errors'] = $errors;
        $_SESSION['form_data'] = $_POST;
        header("Location: register.php");
        exit();
    }

    // Transaction for creating user + supplier
    $conn->begin_transaction();

    try {
        // Create user
        $password_hash = password_hash($password, PASSWORD_DEFAULT);

        $stmt = $conn->prepare("INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $username, $email, $password_hash);
        $stmt->execute();
        $user_id = $conn->insert_id;
        $stmt->close();

        // Insert supplier
        $stmt = $conn->prepare("
            INSERT INTO leveranciers 
            (leverancier_naam, leverancier_opslagplaats, leverancier_plaats, leverarancier_land) 
            VALUES (?, ?, ?, ?)
        ");
        $stmt->bind_param("ssss", 
            $leverancier_naam, 
            $leverancier_opslagplaats, 
            $leverancier_plaats, 
            $leverancier_land,
        );
        $stmt->execute();
        $stmt->close();

        $conn->commit();

        $_SESSION['success_message'] = "Registratie succesvol! U kunt nu inloggen.";
        header("Location: index.php");
        exit();

    } catch (Exception $e) {
        $conn->rollback();
        $_SESSION['registration_errors'] = ["Registratie mislukt: " . $e->getMessage()];
        $_SESSION['form_data'] = $_POST;
        header("Location: register.php");
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registreren - CoffeeShopTurnhout</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body { padding-top: 56px; }
        .header-register {
            background: #2D5E65;
            color: #d2e1ec;
            padding: 60px 0;
            text-align: center;
        }
    </style>
</head>
<body>

<?php include "navbar.php"; ?>

<header class="header-register">
    <div class="container">
        <h1 class="display-4 fw-bold">Leverancier Registratie</h1>
        <p class="lead mt-3">Registreer uw bedrijf als leverancier</p>
    </div>
</header>

<section class="py-5">
    <div class="container">

        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php foreach ($errors as $e): ?>
                        <li><?= htmlspecialchars($e) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-6">
                <div class="card shadow">
                    <div class="card-body p-4">
                        <h3 class="card-title mb-4">Registratieformulier</h3>

                        <form method="post" action="">
                            <h5 class="mb-3">Bedrijfsgegevens</h5>

                            <div class="mb-3">
                                <label for="company_naam" class="form-label">Bedrijfsnaam *</label>
                                <input type="text" class="form-control" id="company_naam" name="company_naam"
                                       value="<?= $form_data['company_naam'] ?? '' ?>" required>
                            </div>

                            <div class="row">
                                <div class="col-md-8 mb-3">
                                    <label for="address" class="form-label">Adres *</label>
                                    <input type="text" class="form-control" id="address" name="address"
                                           value="<?= $form_data['address'] ?? '' ?>" required>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label for="house_number" class="form-label">Huisnummer *</label>
                                    <input type="text" class="form-control" id="house_number" name="house_number"
                                           value="<?= $form_data['house_number'] ?? '' ?>" required>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-4 mb-3">
                                    <label for="postal_code" class="form-label">Postcode *</label>
                                    <input type="text" class="form-control" id="postal_code" name="postal_code"
                                           value="<?= $form_data['postal_code'] ?? '' ?>" required>
                                </div>
                                <div class="col-md-8 mb-3">
                                    <label for="city" class="form-label">Stad *</label>
                                    <input type="text" class="form-control" id="city" name="city"
                                           value="<?= $form_data['city'] ?? '' ?>" required>
                                </div>
                            </div>

                            <div class="mb-3">
                                <label for="country" class="form-label">Land *</label>
                                <input type="text" class="form-control" id="country" name="country"
                                       value="<?= $form_data['country'] ?? '' ?>" required>
                            </div>

                            <hr class="my-4">

                            <h5 class="mb-3">Inloggegevens</h5>

                            <div class="mb-3">
                                <label for="username" class="form-label">Gebruikersnaam *</label>
                                <input type="text" class="form-control" id="username" name="username"
                                       value="<?= $form_data['username'] ?? '' ?>" required>
                            </div>

                            <div class="mb-3">
                                <label for="email" class="form-label">E-mailadres *</label>
                                <input type="email" class="form-control" id="email" name="email"
                                       value="<?= $form_data['email'] ?? '' ?>" required>
                            </div>

                            <div class="mb-3">
                                <label for="password" class="form-label">Wachtwoord *</label>
                                <input type="password" class="form-control" id="password" name="password" required>
                                <small class="form-text text-muted">Minimaal 8 karakters</small>
                            </div>

                            <div class="mb-3">
                                <label for="confirm_password" class="form-label">Bevestig wachtwoord *</label>
                                <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                            </div>

                            <div class="mb-4 form-check">
                                <input type="checkbox" class="form-check-input" id="terms" required>
                                <label class="form-check-label" for="terms">
                                    Ik ga akkoord met de <a href="#">algemene voorwaarden</a> *
                                </label>
                            </div>

                            <button type="submit" class="btn btn-primary w-100 py-2">Registreren</button>

                            <div class="text-center mt-3">
                                <small>Heeft u al een account? <a href="index.php">Log in</a></small>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>
</body>
</html>
