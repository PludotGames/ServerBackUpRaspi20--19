<?php
session_start();
require_once 'config.php';

// Controleer of de gebruiker is ingelogd en adminrechten heeft
if (!isset($_SESSION['gebruiker_id']) || !$_SESSION['is_admin']) {
    die("Toegang geweigerd.");
}

// Haal alle gebruikers op uit de database
try {
    $stmt = $pdo->query("SELECT * FROM gebruikers");
    $gebruikers = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Fout bij ophalen gebruikers: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gebruikers Beheren</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php include 'nav.php'; ?> <!-- Navigatiebalk -->
<div class="container">
    <h1>Gebruikers Beheren</h1>
    <a href="gebruiker_toevoegen.php"><button>Nieuwe Gebruiker Toevoegen</button></a>
    <table>
        <thead>
            <tr>
                <th>Naam</th>
                <th>Email</th>
                <th>Is Admin</th>
                <th>Acties</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($gebruikers as $gebruiker): ?>
            <tr>
                <td><?= htmlspecialchars($gebruiker['naam']); ?></td>
                <td><?= htmlspecialchars($gebruiker['email']); ?></td>
                <td><?= $gebruiker['is_admin'] ? 'Ja' : 'Nee'; ?></td>
                <td>
                    <a href="gebruiker_bewerken.php?id=<?= $gebruiker['gebruiker_id']; ?>">Bewerken</a>
                    <a href="gebruiker_verwijderen.php?id=<?= $gebruiker['gebruiker_id']; ?>" onclick="return confirm('Weet u zeker dat u deze gebruiker wilt verwijderen?');">Verwijderen</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
</body>
</html>
