<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['gebruiker_id'])) {
    header("Location: login.php");
    exit;
}

$gebruiker_id = $_SESSION['gebruiker_id'];

try {
    // Haal de aankopen van de gebruiker op
    $stmt = $pdo->prepare("
        SELECT a.*, w.naam AS winkelnaam
        FROM aankopen a
        JOIN winkels w ON a.winkel_id = w.winkel_id
        WHERE a.gebruiker_id = ?
    ");
    $stmt->execute([$gebruiker_id]);
    $aankopen = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Haal budgetten op die gekoppeld zijn aan de aankopen van de huidige gebruiker
    $stmt = $pdo->prepare("
        SELECT b.budget_id, b.naam AS budgetnaam, b.totaal_bedrag,
               COALESCE(SUM(a.kostprijs), 0) AS totaal_aangekocht
        FROM budgetten b
        LEFT JOIN aankopen a ON b.budget_id = a.budget_id AND a.gebruiker_id = ?
        WHERE b.budget_id IN (
            SELECT DISTINCT budget_id
            FROM aankopen
            WHERE gebruiker_id = ?
        )
        GROUP BY b.budget_id
    ");
    $stmt->execute([$gebruiker_id, $gebruiker_id]);
    $budgetten = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Fout bij ophalen aankopen of budgetten: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mijn Aankopen</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php include 'nav.php'; ?> <!-- Navigatiebalk -->
<div class="container">
    <h1>Mijn Aankopen</h1>
    <table>
        <thead>
            <tr>
                <th>Product</th>
                <th>Beschrijving</th>
                <th>Kostprijs</th>
                <th>Datum</th>
                <th>Winkel</th>
                <th>Acties</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($aankopen as $aankoop): ?>
            <tr>
                <td><?= htmlspecialchars($aankoop['product']); ?></td>
                <td><?= htmlspecialchars($aankoop['beschrijving']); ?></td>
                <td>&euro;<?= number_format($aankoop['kostprijs'], 2, ',', '.'); ?></td>
                <td><?= htmlspecialchars($aankoop['datum']); ?></td>
                <td><?= htmlspecialchars($aankoop['winkelnaam']); ?></td>
                <td>
                    <a href="aankoop_bewerken.php?id=<?= $aankoop['aankoop_id']; ?>">Bewerken</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <h2>Budgetoverzicht</h2>
    <table>
        <thead>
            <tr>
                <th>Budget</th>
                <th>Totaal Bedrag</th>
                <th>Uitgegeven</th>
                <th>Resterend</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($budgetten as $budget): ?>
            <tr>
                <td><?= htmlspecialchars($budget['budgetnaam']); ?></td>
                <td>&euro;<?= number_format($budget['totaal_bedrag'], 2, ',', '.'); ?></td>
                <td>&euro;<?= number_format($budget['totaal_aangekocht'], 2, ',', '.'); ?></td>
                <td>&euro;<?= number_format($budget['totaal_bedrag'] - $budget['totaal_aangekocht'], 2, ',', '.'); ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
</body>
</html>
