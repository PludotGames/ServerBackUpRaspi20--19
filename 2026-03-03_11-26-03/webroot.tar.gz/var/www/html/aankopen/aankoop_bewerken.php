<?php
session_start();
require_once 'config.php';

// Controleer of de gebruiker is ingelogd
if (!isset($_SESSION['gebruiker_id'])) {
    header("Location: login.php");
    exit;
}

// Controleer of een aankoop-ID is opgegeven
if (!isset($_GET['id'])) {
    die("Geen aankoop geselecteerd.");
}

$aankoop_id = $_GET['id'];

try {
    // Haal de aankoop op die bij de ingelogde gebruiker hoort
    $stmt = $pdo->prepare("SELECT * FROM aankopen WHERE aankoop_id = ? AND gebruiker_id = ?");
    $stmt->execute([$aankoop_id, $_SESSION['gebruiker_id']]);
    $aankoop = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$aankoop) {
        die("Aankoop niet gevonden of u heeft geen rechten om deze aankoop te bewerken.");
    }

    // Als het formulier is verzonden, werk de gegevens bij
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $product = $_POST['product'] ?? '';
        $beschrijving = $_POST['beschrijving'] ?? '';
        $kostprijs = $_POST['kostprijs'] ?? 0;
        $datum = $_POST['datum'] ?? '';
        $winkel_id = $_POST['winkel_id'] ?? 0;

        $stmt = $pdo->prepare("UPDATE aankopen SET product = ?, beschrijving = ?, kostprijs = ?, datum = ?, winkel_id = ? WHERE aankoop_id = ? AND gebruiker_id = ?");
        $stmt->execute([$product, $beschrijving, $kostprijs, $datum, $winkel_id, $aankoop_id, $_SESSION['gebruiker_id']]);

        header("Location: mijn_aankopen.php");
        exit;
    }

    // Haal een lijst van winkels op voor de select-lijst
    $winkels = $pdo->query("SELECT winkel_id, naam FROM winkels")->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Fout bij ophalen of bijwerken van aankoop: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aankoop Bewerken</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php include 'nav.php'; ?> <!-- Navigatiebalk -->
<div class="container">
    <h1>Aankoop Bewerken</h1>
    <form method="POST">
        <label>Product:</label>
        <input type="text" name="product" value="<?= htmlspecialchars($aankoop['product']); ?>" required>

        <label>Beschrijving:</label>
        <textarea name="beschrijving"><?= htmlspecialchars($aankoop['beschrijving']); ?></textarea>

        <label>Kostprijs:</label>
        <input type="number" step="0.01" name="kostprijs" value="<?= htmlspecialchars($aankoop['kostprijs']); ?>" required>

        <label>Datum:</label>
        <input type="date" name="datum" value="<?= htmlspecialchars($aankoop['datum']); ?>" required>

        <label>Winkel:</label>
        <select name="winkel_id" required>
            <?php foreach ($winkels as $winkel): ?>
                <option value="<?= $winkel['winkel_id']; ?>" <?= $aankoop['winkel_id'] == $winkel['winkel_id'] ? 'selected' : ''; ?>>
                    <?= htmlspecialchars($winkel['naam']); ?>
                </option>
            <?php endforeach; ?>
        </select>

        <input type="submit" value="Opslaan">
    </form>
</div>
</body>
</html>
