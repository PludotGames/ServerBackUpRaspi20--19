<?php
session_start();
require_once 'config.php';

// Controleer of de gebruiker adminrechten heeft
if (!isset($_SESSION['gebruiker_id']) || !$_SESSION['is_admin']) {
    die("Toegang geweigerd.");
}

// Controleer of een ID is opgegeven
if (!isset($_GET['id'])) {
    die("Geen gebruiker geselecteerd.");
}

$gebruiker_id = $_GET['id'];

try {
    // Haal de gegevens van de geselecteerde gebruiker op
    $stmt = $pdo->prepare("SELECT * FROM gebruikers WHERE gebruiker_id = ?");
    $stmt->execute([$gebruiker_id]);
    $gebruiker = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$gebruiker) {
        die("Gebruiker niet gevonden.");
    }

    // Als het formulier is verzonden, werk de gegevens bij
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $naam = $_POST['naam'] ?? '';
        $email = $_POST['email'] ?? '';
        $is_admin = isset($_POST['is_admin']) ? 1 : 0;

        // Update wachtwoord alleen als het veld is ingevuld
        if (!empty($_POST['wachtwoord'])) {
            $wachtwoord = password_hash($_POST['wachtwoord'], PASSWORD_BCRYPT);
            $stmt = $pdo->prepare("UPDATE gebruikers SET naam = ?, email = ?, wachtwoord = ?, is_admin = ? WHERE gebruiker_id = ?");
            $stmt->execute([$naam, $email, $wachtwoord, $is_admin, $gebruiker_id]);
        } else {
            $stmt = $pdo->prepare("UPDATE gebruikers SET naam = ?, email = ?, is_admin = ? WHERE gebruiker_id = ?");
            $stmt->execute([$naam, $email, $is_admin, $gebruiker_id]);
        }

        header("Location: gebruikers.php");
        exit;
    }
} catch (PDOException $e) {
    die("Fout bij ophalen of bijwerken van gebruiker: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gebruiker Bewerken</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php include 'nav.php'; ?> <!-- Navigatiebalk -->
<div class="container">
    <h1>Gebruiker Bewerken</h1>
    <form method="POST">
        <label>Naam:</label>
        <input type="text" name="naam" value="<?= htmlspecialchars($gebruiker['naam']); ?>" required>

        <label>Email:</label>
        <input type="email" name="email" value="<?= htmlspecialchars($gebruiker['email']); ?>" required>

        <label>Wachtwoord (leeg laten om niet te wijzigen):</label>
        <input type="password" name="wachtwoord">

        <label>
            <input type="checkbox" name="is_admin" <?= $gebruiker['is_admin'] ? 'checked' : ''; ?>> Adminrechten
        </label>

        <input type="submit" value="Opslaan">
    </form>
</div>
</body>
</html>
