<?php
$host = 'localhost';
$dbname = 'aankoopDB';
$user = 'aankoper';
$pass = 'aankopenpw';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Fout bij de databaseverbinding: " . $e->getMessage());
}
?>
