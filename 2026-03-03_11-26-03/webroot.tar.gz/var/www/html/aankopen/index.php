<?php
session_start();
if (!isset($_SESSION['gebruiker_id'])) {
    header("Location: login.php");
    exit;
}
$is_admin = $_SESSION['is_admin'];
$gebruiker_naam = $_SESSION['naam']; // Haal de naam van de gebruiker op
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Overzicht</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<nav class="navbar">
    <ul>
        <li><strong>Aangemeld als: <?= htmlspecialchars($gebruiker_naam); ?></strong></li> <!-- Toon wie is aangemeld -->
        <li><a href="index.php">Home</a></li>
        <li class="dropdown">
            <a href="#">Aankopen</a>
            <div class="dropdown-content">
                <a href="mijn_aankopen.php">Mijn Aankopen</a>
                <a href="aankoop_toevoegen.php">Aankoop Toevoegen</a>
            </div>
        </li>
        <li class="dropdown">
            <a href="#">Winkels</a>
            <div class="dropdown-content">
                <a href="winkels.php">Winkels Bekijken</a>
                <a href="winkel_toevoegen.php">Winkel Toevoegen</a>
            </div>
        </li>
        <li><a href="budget.php">Mijn Budget</a></li>
        <?php if ($is_admin): ?>
        <li class="dropdown">
            <a href="#">Admin</a>
            <div class="dropdown-content">
                <a href="gebruikers.php">Gebruikers Beheren</a>
                <a href="budget_beheren.php">Budget Beheren</a>
            </div>
        </li>
        <?php endif; ?>
        <li><a href="logout.php">Uitloggen</a></li>
    </ul>
</nav>
<div class="container">
    <h1>Welkom op de Budget & Aankopen website!</h1>
    <p>Indien je goeie punten  behaalt in het vak software,
dan zal Mr. Moeskops jouw een budget toewijzen waarmee
je de aankoop (of meervoud hiervan)van jouw dromen kan waarmaken op zijn kosten.
<br>
<strong>Let op</strong>, dit is enkel mogelijk met de betaalkaarten die Mr. Moeskops beheert vanuit deze webomgeving.
<br><br>
Hier kunt u uw aankopen beheren, winkels bekijken en uw budget raadplegen.
<br><br><br><strong>
Let wel, je dient onder het opgegeven budget te blijven!</strong>
<br>
<sub>(ja, jij ook Ludovic ;-)</sub>
</p>
</div>
</body>
</html>
