<?php
session_start();
require_once 'config.php';

if (isset($_SESSION['gebruiker_id'])) {
    header("Location: index.php");
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $naam = $_POST['naam'];
    $wachtwoord = $_POST['wachtwoord'];

    $stmt = $pdo->prepare("SELECT * FROM gebruikers WHERE naam = ?");
    $stmt->execute([$naam]);
    $gebruiker = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($gebruiker && $gebruiker['wachtwoord'] === $wachtwoord) {
        $_SESSION['gebruiker_id'] = $gebruiker['gebruiker_id'];
        $_SESSION['naam'] = $gebruiker['naam']; // Sla de naam op in de sessie
        $_SESSION['is_admin'] = $gebruiker['is_admin'];
        header("Location: index.php");
        exit;
    } else {
        $error = "Ongeldige inloggegevens!";
    }
}
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inloggen</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            background: #f0f2f5;
        }
        .login-container {
            background: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
        }
        .login-container h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        .login-container .error {
            color: red;
            text-align: center;
            margin-bottom: 10px;
        }
        .password-container {
            position: relative;
        }
        .show-password {
            font-size: 14px;
            margin-top: 10px;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
<div class="login-container">
    <h2>Inloggen</h2>
    <?php if ($error): ?>
        <p class="error"><?= htmlspecialchars($error) ?></p>
    <?php endif; ?>
    <form method="POST">
        <label for="naam">Naam:</label>
        <input type="text" id="naam" name="naam" required>

        <label for="wachtwoord">Wachtwoord:</label>
        <div class="password-container">
            <input type="password" id="wachtwoord" name="wachtwoord" required>
        </div>
        <label class="show-password">
            <input type="checkbox" id="togglePassword"> Toon wachtwoord
        </label>

        <input type="submit" value="Inloggen">
    </form>
</div>

<script>
    // JavaScript voor het tonen/verbergen van het wachtwoord
    const togglePassword = document.getElementById('togglePassword');
    const passwordInput = document.getElementById('wachtwoord');

    togglePassword.addEventListener('change', function () {
        if (this.checked) {
            passwordInput.type = 'text'; // Wachtwoord zichtbaar maken
        } else {
            passwordInput.type = 'password'; // Wachtwoord verbergen
        }
    });
</script>
</body>
</html>
