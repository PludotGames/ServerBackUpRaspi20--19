<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['gebruiker_id'])) {
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $naam = $_POST['naam'] ?? '';
    $beschrijving = $_POST['beschrijving'] ?? '';
    $adres = $_POST['adres'] ?? '';
    $telefoon = $_POST['telefoon'] ?? '';
    $email = $_POST['email'] ?? '';
    $sterren = $_POST['sterren'] ?? 0;

    try {
        $stmt = $pdo->prepare("INSERT INTO winkels (naam, beschrijving, adres, telefoon, email, sterren) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$naam, $beschrijving, $adres, $telefoon, $email, $sterren]);
        header("Location: winkels.php");
        exit;
    } catch (PDOException $e) {
        die("Fout bij toevoegen winkel: " . $e->getMessage());
    }
}
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Winkel Toevoegen</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php include 'nav.php'; ?> <!-- Navigatiebalk -->
<div class="container">
    <h1>Nieuwe Winkel Toevoegen</h1>
    <form method="POST">
        <label>Naam:</label>
        <input type="text" name="naam" required>

        <label>Beschrijving:</label>
        <textarea name="beschrijving"></textarea>

        <label>Adres:</label>
        <input type="text" name="adres">

        <label>Telefoon:</label>
        <input type="text" name="telefoon">

        <label>Email:</label>
        <input type="email" name="email">

        <label>Sterren (1-5):</label>
        <input type="number" name="sterren" min="1" max="5" value="5" required>

        <input type="submit" value="Toevoegen">
    </form>
</div>
</body>
</html>
