<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['gebruiker_id'])) {
    header("Location: login.php");
    exit;
}

// Haal alle winkels op uit de database
try {
    $stmt = $pdo->query("SELECT * FROM winkels");
    $winkels = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Fout bij ophalen winkels: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Winkels</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php include 'nav.php'; ?> <!-- Navigatiebalk -->
<div class="container">
    <h1>Winkels</h1>
    <table>
        <thead>
            <tr>
                <th>Naam</th>
                <th>Beschrijving</th>
                <th>Adres</th>
                <th>Telefoon</th>
                <th>Email</th>
                <th>Sterren</th>
                <?php if ($_SESSION['is_admin']): ?>
                <th>Acties</th>
                <?php endif; ?>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($winkels as $winkel): ?>
            <tr>
                <td><?= htmlspecialchars($winkel['naam']); ?></td>
                <td><?= htmlspecialchars($winkel['beschrijving']); ?></td>
                <td><?= htmlspecialchars($winkel['adres']); ?></td>
                <td><?= htmlspecialchars($winkel['telefoon']); ?></td>
                <td><?= htmlspecialchars($winkel['email']); ?></td>
                <td><?= htmlspecialchars($winkel['sterren']); ?>/5</td>
                <?php if ($_SESSION['is_admin']): ?>
                <td><a href="winkel_bewerken.php?id=<?= $winkel['winkel_id']; ?>">Bewerken</a></td>
                <?php endif; ?>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <?php if ($_SESSION['is_admin']): ?>
    <a href="winkel_toevoegen.php"><button>Nieuwe Winkel Toevoegen</button></a>
    <?php endif; ?>
</div>
</body>
</html>
