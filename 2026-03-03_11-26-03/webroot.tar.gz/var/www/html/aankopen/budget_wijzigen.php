<?php
session_start();
require_once 'config.php';

// Controleer of de gebruiker adminrechten heeft
if (!isset($_SESSION['gebruiker_id']) || !$_SESSION['is_admin']) {
    die("Toegang geweigerd.");
}

// Controleer of een budget-ID is opgegeven
if (!isset($_GET['id'])) {
    die("Geen budget geselecteerd. Zorg dat je een geldig budget-ID meegeeft in de URL.");
}

$budget_id = $_GET['id'];

try {
    // Haal de gegevens van het geselecteerde budget op
    $stmt = $pdo->prepare("SELECT * FROM budgetten WHERE budget_id = ?");
    $stmt->execute([$budget_id]);
    $budget = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$budget) {
        die("Budget niet gevonden.");
    }

    // Als het formulier is verzonden, werk de gegevens bij
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $naam = $_POST['naam'] ?? '';
        $beschrijving = $_POST['beschrijving'] ?? '';
        $jaartal = $_POST['jaartal'] ?? '';
        $totaal_bedrag = $_POST['totaal_bedrag'] ?? 0;
        $opmerkingen = $_POST['opmerkingen'] ?? '';

        $stmt = $pdo->prepare("UPDATE budgetten SET naam = ?, beschrijving = ?, jaartal = ?, totaal_bedrag = ?, opmerkingen = ? WHERE budget_id = ?");
        $stmt->execute([$naam, $beschrijving, $jaartal, $totaal_bedrag, $opmerkingen, $budget_id]);

        header("Location: budget_beheren.php");
        exit;
    }
} catch (PDOException $e) {
    die("Fout bij ophalen of bijwerken van budget: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Budget Wijzigen</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php include 'nav.php'; ?> <!-- Navigatiebalk -->
<div class="container">
    <h1>Budget Wijzigen</h1>
    <form method="POST">
        <label>Naam:</label>
        <input type="text" name="naam" value="<?= htmlspecialchars($budget['naam']); ?>" required>

        <label>Beschrijving:</label>
        <textarea name="beschrijving"><?= htmlspecialchars($budget['beschrijving']); ?></textarea>

        <label>Jaartal:</label>
        <input type="text" name="jaartal" value="<?= htmlspecialchars($budget['jaartal']); ?>" required>

        <label>Totaal Bedrag:</label>
        <input type="number" step="0.01" name="totaal_bedrag" value="<?= htmlspecialchars($budget['totaal_bedrag']); ?>" required>

        <label>Opmerkingen:</label>
        <textarea name="opmerkingen"><?= htmlspecialchars($budget['opmerkingen']); ?></textarea>

        <input type="submit" value="Opslaan">
    </form>
</div>
</body>
</html>
