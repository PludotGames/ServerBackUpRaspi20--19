<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['gebruiker_id'])) {
    header("Location: login.php");
    exit;
}

try {
    // Haal de budgetten op die gekoppeld zijn aan de gebruiker via aankopen
    $stmt = $pdo->prepare("
        SELECT DISTINCT b.* 
        FROM budgetten b
        JOIN aankopen a ON b.budget_id = a.budget_id
        WHERE a.gebruiker_id = ?
    ");
    $stmt->execute([$_SESSION['gebruiker_id']]);
    $budgetten = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Fout bij ophalen budgetten: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mijn Budget</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php include 'nav.php'; ?> <!-- Navigatiebalk -->
<div class="container">
    <h1>Mijn Budget</h1>
    <?php if (count($budgetten) > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>Naam</th>
                    <th>Beschrijving</th>
                    <th>Jaartal</th>
                    <th>Totaal Bedrag</th>
                    <th>Opmerkingen</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($budgetten as $budget): ?>
                <tr>
                    <td><?= htmlspecialchars($budget['naam']); ?></td>
                    <td><?= htmlspecialchars($budget['beschrijving']); ?></td>
                    <td><?= htmlspecialchars($budget['jaartal']); ?></td>
                    <td>&euro;<?= number_format($budget['totaal_bedrag'], 2, ',', '.'); ?></td>
                    <td><?= htmlspecialchars($budget['opmerkingen']); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>U heeft momenteel geen gekoppelde budgetten.</p>
    <?php endif; ?>
</div>
</body>
</html>
