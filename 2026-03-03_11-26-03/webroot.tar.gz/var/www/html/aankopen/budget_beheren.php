<?php
session_start();
require_once 'config.php';

// Controleer of de gebruiker adminrechten heeft
if (!isset($_SESSION['gebruiker_id']) || !$_SESSION['is_admin']) {
    die("Toegang geweigerd.");
}

try {
    // Haal alle budgetten op
    $stmt = $pdo->query("
        SELECT b.*, 
               (SELECT GROUP_CONCAT(g.naam SEPARATOR ', ') 
                FROM gebruikers g 
                JOIN aankopen a ON g.gebruiker_id = a.gebruiker_id 
                WHERE a.budget_id = b.budget_id) AS gekoppelde_gebruikers
        FROM budgetten b
    ");
    $budgetten = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Fout bij ophalen van budgetten: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Budget Beheren</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php include 'nav.php'; ?> <!-- Navigatiebalk -->
<div class="container">
    <h1>Budget Beheren</h1>
    <table>
        <thead>
            <tr>
                <th>Naam</th>
                <th>Jaartal</th>
                <th>Totaal Bedrag</th>
                <th>Opmerkingen</th>
                <th>Gebruikers</th>
                <th>Acties</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($budgetten as $budget): ?>
            <tr>
                <td><?= htmlspecialchars($budget['naam']); ?></td>
                <td><?= htmlspecialchars($budget['jaartal']); ?></td>
                <td>&euro;<?= number_format($budget['totaal_bedrag'], 2, ',', '.'); ?></td>
                <td><?= htmlspecialchars($budget['opmerkingen']); ?></td>
                <td><?= htmlspecialchars($budget['gekoppelde_gebruikers'] ?: 'Geen gebruikers gekoppeld'); ?></td>
                <td>
                    <a href="budget_wijzigen.php?id=<?= $budget['budget_id']; ?>">Wijzigen</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
</body>
</html>
