<?php
session_start();
require_once 'config.php';

// Controleer of de gebruiker adminrechten heeft
if (!isset($_SESSION['gebruiker_id']) || !$_SESSION['is_admin']) {
    die("Toegang geweigerd.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $naam = $_POST['naam'] ?? '';
    $email = $_POST['email'] ?? '';
    $wachtwoord = $_POST['wachtwoord'] ?? '';
    $is_admin = isset($_POST['is_admin']) ? 1 : 0;

    try {
        $stmt = $pdo->prepare("INSERT INTO gebruikers (naam, email, wachtwoord, is_admin) VALUES (?, ?, ?, ?)");
        $stmt->execute([$naam, $email, password_hash($wachtwoord, PASSWORD_BCRYPT), $is_admin]);
        header("Location: gebruikers.php");
        exit;
    } catch (PDOException $e) {
        die("Fout bij toevoegen gebruiker: " . $e->getMessage());
    }
}
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nieuwe Gebruiker Toevoegen</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php include 'nav.php'; ?> <!-- Navigatiebalk -->
<div class="container">
    <h1>Nieuwe Gebruiker Toevoegen</h1>
    <form method="POST">
        <label>Naam:</label>
        <input type="text" name="naam" required>

        <label>Email:</label>
        <input type="email" name="email" required>

        <label>Wachtwoord:</label>
        <input type="password" name="wachtwoord" required>

        <label>
            <input type="checkbox" name="is_admin"> Adminrechten
        </label>

        <input type="submit" value="Toevoegen">
    </form>
</div>
</body>
</html>
