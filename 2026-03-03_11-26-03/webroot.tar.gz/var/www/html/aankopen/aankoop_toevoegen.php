<?php
session_start();
require_once 'config.php';

// Toon fouten tijdens debugging (alleen in een testomgeving)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['gebruiker_id'])) {
    header("Location: login.php");
    exit;
}

$gebruiker_id = $_SESSION['gebruiker_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product = $_POST['product'];
    $beschrijving = $_POST['beschrijving'];
    $kostprijs = $_POST['kostprijs'];
    $datum = $_POST['datum'];
    $winkel_id = $_POST['winkel_id'];
    $budget_id = $_POST['budget_id'];

    try {
        $stmt = $pdo->prepare("INSERT INTO aankopen (gebruiker_id, winkel_id, budget_id, product, beschrijving, kostprijs, datum) VALUES (?,?,?,?,?,?,?)");
        $stmt->execute([$gebruiker_id, $winkel_id, $budget_id, $product, $beschrijving, $kostprijs, $datum]);
        header("Location: mijn_aankopen.php");
        exit;
    } catch (PDOException $e) {
        die("Fout bij het toevoegen van een aankoop: " . $e->getMessage());
    }
}

// Haal de lijst van winkels op
$winkels = $pdo->query("SELECT winkel_id, naam FROM winkels")->fetchAll(PDO::FETCH_ASSOC);

// Haal budgetten op via gekoppelde aankopen
$budgets = $pdo->prepare("
    SELECT DISTINCT b.* 
    FROM budgetten b
    JOIN aankopen a ON b.budget_id = a.budget_id
    WHERE a.gebruiker_id = ?
");
$budgets->execute([$gebruiker_id]);
$budgets = $budgets->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aankoop Toevoegen</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php include 'nav.php'; ?>
<div class="container">
    <h1>Aankoop Toevoegen</h1>
    <form method="POST">
        <label>Product:</label>
        <input type="text" name="product" required>

        <label>Beschrijving:</label>
        <textarea name="beschrijving"></textarea>

        <label>Kostprijs:</label>
        <input type="number" step="0.01" name="kostprijs" required>

        <label>Datum:</label>
        <input type="date" name="datum" required>

        <label>Winkel:</label>
        <?php if (count($winkels) > 0): ?>
        <select name="winkel_id" required>
            <?php foreach($winkels as $winkel): ?>
            <option value="<?= $winkel['winkel_id']; ?>"><?= htmlspecialchars($winkel['naam']); ?></option>
            <?php endforeach; ?>
        </select>
        <?php else: ?>
        <p>Geen winkels beschikbaar.</p>
        <?php endif; ?>

        <label>Budget:</label>
        <?php if (count($budgets) > 0): ?>
        <select name="budget_id" required>
            <?php foreach($budgets as $budget): ?>
            <option value="<?= $budget['budget_id']; ?>"><?= htmlspecialchars($budget['naam']); ?></option>
            <?php endforeach; ?>
        </select>
        <?php else: ?>
        <p>Geen budgetten beschikbaar.</p>
        <?php endif; ?>

        <input type="submit" value="Toevoegen">
    </form>
</div>
</body>
</html>
