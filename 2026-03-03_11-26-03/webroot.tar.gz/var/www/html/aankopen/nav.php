<?php
$is_admin = $_SESSION['is_admin'];
$gebruiker_naam = $_SESSION['naam'];
?>
<nav class="navbar">
    <ul>
        <li><strong>Aangemeld als: <?= htmlspecialchars($gebruiker_naam); ?></strong></li>
        <li><a href="index.php">Home</a></li>
        <li class="dropdown">
            <a href="#">Aankopen</a>
            <div class="dropdown-content">
                <a href="mijn_aankopen.php">Mijn Aankopen</a>
                <a href="aankoop_toevoegen.php">Aankoop Toevoegen</a>
            </div>
        </li>
        <li class="dropdown">
            <a href="#">Winkels</a>
            <div class="dropdown-content">
                <a href="winkels.php">Winkels Bekijken</a>
                <a href="winkel_toevoegen.php">Winkel Toevoegen</a>
            </div>
        </li>
        <li><a href="budget.php">Mijn Budget</a></li>
        <?php if ($is_admin): ?>
        <li class="dropdown">
            <a href="#">Admin</a>
            <div class="dropdown-content">
                <a href="gebruikers.php">Gebruikers Beheren</a>
                <a href="budget_beheren.php">Budget Beheren</a>
            </div>
        </li>
        <?php endif; ?>
        <li><a href="logout.php">Uitloggen</a></li>
    </ul>
</nav>
