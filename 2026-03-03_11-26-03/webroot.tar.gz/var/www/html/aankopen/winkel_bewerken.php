<?php
session_start();
require_once 'config.php';

// Controleer of de gebruiker adminrechten heeft
if (!isset($_SESSION['gebruiker_id']) || !$_SESSION['is_admin']) {
    die("Toegang geweigerd.");
}

// Controleer of een winkel-ID is opgegeven
if (!isset($_GET['id'])) {
    die("Geen winkel geselecteerd. Zorg dat je een geldig winkel-ID meegeeft in de URL.");
}

$winkel_id = $_GET['id'];

try {
    // Haal de gegevens van de geselecteerde winkel op
    $stmt = $pdo->prepare("SELECT * FROM winkels WHERE winkel_id = ?");
    $stmt->execute([$winkel_id]);
    $winkel = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$winkel) {
        die("Winkel niet gevonden.");
    }

    // Als het formulier is verzonden, werk de gegevens bij
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $naam = $_POST['naam'] ?? '';
        $beschrijving = $_POST['beschrijving'] ?? '';
        $adres = $_POST['adres'] ?? '';
        $telefoon = $_POST['telefoon'] ?? '';
        $email = $_POST['email'] ?? '';
        $sterren = $_POST['sterren'] ?? 0;

        $stmt = $pdo->prepare("UPDATE winkels SET naam = ?, beschrijving = ?, adres = ?, telefoon = ?, email = ?, sterren = ? WHERE winkel_id = ?");
        $stmt->execute([$naam, $beschrijving, $adres, $telefoon, $email, $sterren, $winkel_id]);

        header("Location: winkels.php");
        exit;
    }
} catch (PDOException $e) {
    die("Fout bij ophalen of bijwerken van winkel: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Winkel Bewerken</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php include 'nav.php'; ?> <!-- Navigatiebalk -->
<div class="container">
    <h1>Winkel Bewerken</h1>
    <form method="POST">
        <label>Naam:</label>
        <input type="text" name="naam" value="<?= htmlspecialchars($winkel['naam']); ?>" required>

        <label>Beschrijving:</label>
        <textarea name="beschrijving"><?= htmlspecialchars($winkel['beschrijving']); ?></textarea>

        <label>Adres:</label>
        <input type="text" name="adres" value="<?= htmlspecialchars($winkel['adres']); ?>" required>

        <label>Telefoon:</label>
        <input type="text" name="telefoon" value="<?= htmlspecialchars($winkel['telefoon']); ?>" required>

        <label>Email:</label>
        <input type="email" name="email" value="<?= htmlspecialchars($winkel['email']); ?>" required>

        <label>Sterren (1-5):</label>
        <input type="number" name="sterren" min="1" max="5" value="<?= htmlspecialchars($winkel['sterren']); ?>" required>

        <input type="submit" value="Opslaan">
    </form>
</div>
</body>
</html>
