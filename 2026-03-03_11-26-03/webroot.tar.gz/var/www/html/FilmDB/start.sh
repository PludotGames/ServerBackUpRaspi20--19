#!/bin/bash

# installatie voor FilmDB

# Functie om script te onderbreken (pauze)
function pause(){
   read -p "$*"
}

printf -- '-%.0s' {1..80}; echo ""
echo Welkom bij het installatiescript voor filmDB
echo -n "Deze installatie start op: "
date

# teken een lijn
printf -- '-%.0s' {1..80}; echo ""

# onderbreek script indien nodig
pause 'Druk op [Enter] toets om database en DBuser te installeren, ctrl^c om te onderbreken...'
sudo mysql -u root -p < stap1filmDB.sql

# teken een lijn
printf -- '-%.0s' {1..80}; echo ""
pause 'Druk op [Enter] toets om tabellen, data en PHPuser te installeren, ctrl^c om te onderbreken...'
mysql -u film -h localhost -pfilmpw < stap2filmDB.sql

printf -- '-%.0s' {1..80}; echo ""
pause 'Druk op [Enter] toets om webpages op /var/www/html/film te installeren, ctrl^c om te onderbreken...'
sudo mkdir /var/www/html/film/
sudo cp ./web/* /var/www/html/film/

printf -- '-%.0s' {1..80}; echo ""
echo Einde van installatiescript
