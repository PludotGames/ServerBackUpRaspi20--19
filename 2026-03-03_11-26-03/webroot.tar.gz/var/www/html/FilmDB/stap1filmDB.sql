    CREATE DATABASE filmDB;
USE filmDB;


CREATE USER 'film'@'localhost' IDENTIFIED BY 'filmpw';

GRANT ALL PRIVILEGES ON filmDB.* TO 'film'@'localhost';
-- FLUSH PRIVILEGES;
