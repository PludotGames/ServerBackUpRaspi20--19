<?php
include 'db_connection.php'; // Zorg ervoor dat je een bestand hebt voor de databaseverbinding

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $naam = htmlspecialchars($_POST['naam']);
    $locatie = htmlspecialchars($_POST['locatie']);
    $sportsoort = htmlspecialchars($_POST['sportsoort']);
    $oprichtingsjaar = htmlspecialchars($_POST['oprichtingsjaar']);
    $aantal_leden = htmlspecialchars($_POST['aantal_leden']);

    $stmt = $conn->prepare("INSERT INTO clubs (naam, locatie, sportsoort, oprichtingsjaar, aantal_leden) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssii", $naam, $locatie, $sportsoort, $oprichtingsjaar, $aantal_leden);

    if ($stmt->execute()) {
        echo "<p class='success-msg'>Club succesvol toegevoegd!</p>";
    } else {
        echo "<p class='error-msg'>Fout bij het toevoegen van club: " . $stmt->error . "</p>";
    }

    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Club Toevoegen</title>
    <style>
        .form-container {
            max-width: 500px;
            margin: 0 auto;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .form-container label {
            display: block;
            margin-bottom: 5px;
        }
        .form-container input,
        .form-container select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        .form-container button {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            background: #4CAF50;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .form-container button:hover {
            background: #45a049;
        }
        .success-msg {
            color: #2ecc71;
            font-weight: bold;
            text-align: center;
        }
        .error-msg {
            color: #e74c3c;
            font-weight: bold;
            text-align: center;
        }
    </style>
</head>
<body>
    <h2>Club Toevoegen</h2>
    <div class="form-container">
        <form method="POST" action="index.php?view=club_add">
            <label for="naam">Naam:</label>
            <input type="text" id="naam" name="naam" required>

            <label for="locatie">Locatie:</label>
            <input type="text" id="locatie" name="locatie" required>

            <label for="sportsoort">Sportsoort:</label>
            <input type="text" id="sportsoort" name="sportsoort" required>

            <label for="oprichtingsjaar">Oprichtingsjaar:</label>
            <input type="number" id="oprichtingsjaar" name="oprichtingsjaar" required>

            <label for="aantal_leden">Aantal Leden:</label>
            <input type="number" id="aantal_leden" name="aantal_leden" required>

            <button type="submit" class="btn">Toevoegen</button>
        </form>
    </div>
</body>
</html>



