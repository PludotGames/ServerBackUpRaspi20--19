<?php
include 'db_connection.php'; // Zorg ervoor dat je een bestand hebt voor de databaseverbinding

echo "<h2>Overzicht van alle Clubs</h2>";
    $result = $conn->query("SELECT * FROM clubs");
    if ($result->num_rows > 0) {
        echo "<div class='table-container'><table>";
        echo "<tr>
                <th>Club ID</th>
                <th>Naam</th>
                <th>Locatie</th>
                <th>Sportsoort</th>
                <th>Oprichtingsjaar</th>
                <th>Aantal Leden</th>
                </tr>";
        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                    <td>" . htmlspecialchars($row['club_id']) . "</td>
                    <td>" . htmlspecialchars($row['naam']) . "</td>
                    <td>" . htmlspecialchars($row['locatie']) . "</td>
                    <td>" . htmlspecialchars($row['sportsoort']) . "</td>
                    <td>" . htmlspecialchars($row['oprichtingsjaar']) . "</td>
                    <td>" . htmlspecialchars($row['aantal_leden']) . "</td>
                    </tr>";
        }
        echo "</table></div>";
    } else {
        echo "<p class='error-msg'>Geen clubs gevonden.</p>";
    }
?>