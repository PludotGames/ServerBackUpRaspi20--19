<?php
include 'db_connection.php'; // Zorg ervoor dat je een bestand hebt voor de databaseverbinding

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $query = "UPDATE clubs 
              JOIN (SELECT club_id, COUNT(*) AS aantal_leden FROM leden GROUP BY club_id) lid 
              ON clubs.club_id = lid.club_id 
              SET clubs.aantal_leden = lid.aantal_leden";

    if ($conn->query($query) === TRUE) {
        echo "<p class='success-msg'>Aantal leden per club geüpdatet!</p>";
    } else {
        echo "<p class='error-msg'>Fout bij het updaten van aantal leden: " . $conn->error . "</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Aantal Leden per Club</title>
    <style>
        .form-container {
            max-width: 500px;
            margin: 0 auto;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .form-container button {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            background: #4CAF50;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .form-container button:hover {
            background: #45a049;
        }
        .success-msg {
            color: #2ecc71;
            font-weight: bold;
            text-align: center;
        }
        .error-msg {
            color: #e74c3c;
            font-weight: bold;
            text-align: center;
        }
    </style>
</head>
<body>
    <h2>Update Aantal Leden per Club</h2>
    <div class="form-container">
        Met een druk op deze knop worden alle actieve leden herteld en het aantal wordt aangepast in tabel Clubs
        <form method="POST" action="index.php?view=update_club_members">
            <button type="submit" class="btn">Update Aantal Leden</button>
        </form>
    </div>
</body>
</html>