<?php
include 'db_connection.php'; // Zorg ervoor dat je een bestand hebt voor de databaseverbinding

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['lid_id'])) {
    // Update het lid
    $lid_id = htmlspecialchars($_POST['lid_id']);
    $naam = htmlspecialchars($_POST['naam']);
    $geboortedatum = htmlspecialchars($_POST['geboortedatum']);
    $geslacht = htmlspecialchars($_POST['geslacht']);
    $straat = htmlspecialchars($_POST['straat']);
    $huisnummer = htmlspecialchars($_POST['huisnummer']);
    $postnummer = htmlspecialchars($_POST['postnummer']);
    $plaats = htmlspecialchars($_POST['plaats']);
    $inschrijving = htmlspecialchars($_POST['inschrijving']);
    $uitschrijving = !empty($_POST['uitschrijving']) ? htmlspecialchars($_POST['uitschrijving']) : null;
    $club_id = htmlspecialchars($_POST['club_id']);

    $stmt = $conn->prepare("UPDATE leden SET naam=?, geboortedatum=?, geslacht=?, straat=?, huisnummer=?, postnummer=?, plaats=?, inschrijving=?, uitschrijving=?, club_id=? WHERE lid_id=?");
    $stmt->bind_param("ssssssssssi", $naam, $geboortedatum, $geslacht, $straat, $huisnummer, $postnummer, $plaats, $inschrijving, $uitschrijving, $club_id, $lid_id);

    if ($stmt->execute()) {
        echo "<p class='success-msg'>Lid succesvol bijgewerkt!</p>";
    } else {
        echo "<p class='error-msg'>Fout bij het bijwerken van lid: " . $stmt->error . "</p>";
    }

    $stmt->close();
} elseif (isset($_GET['lid_id'])) {
    // Laad de gegevens van het lid
    $lid_id = htmlspecialchars($_GET['lid_id']);
    $result = $conn->query("SELECT * FROM leden WHERE lid_id = $lid_id");

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
    } else {
        echo "<p class='error-msg'>Lid niet gevonden.</p>";
        exit;
    }
} else {
    // Vraag om het lid_id
    echo '<h2>Lid Aanpassen</h2>
            <div class="form-container" style="max-width: 500px; margin: 0 auto;">
            <form method="GET" action="index.php">
                <input type="hidden" name="view" value="member_edit">
                <label for="lid_id">Lid ID:</label>
                <input type="number" id="lid_id" name="lid_id" required>
                <button type="submit" class="btn">Zoeken</button>
            </form>
          </div>';
    exit;
}
?>

<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lid Aanpassen</title>
    <style>
        .form-container {
            max-width: 500px;
            margin: 0 auto;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .form-container label {
            display: block;
            margin-bottom: 5px;
        }
        .form-container input,
        .form-container select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        .form-container button {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            background: #4CAF50;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .form-container button:hover {
            background: #45a049;
        }
        .success-msg {
            color: #2ecc71;
            font-weight: bold;
            text-align: center;
        }
        .error-msg {
            color: #e74c3c;
            font-weight: bold;
            text-align: center;
        }
    </style>
</head>
<body>
    <h2>Lid Aanpassen</h2>
    <div class="form-container">
        <form method="POST" action="index.php?view=member_edit">
            <input type="hidden" name="lid_id" value="<?php echo htmlspecialchars($row['lid_id']); ?>">

            <label for="naam">Naam:</label>
            <input type="text" id="naam" name="naam" value="<?php echo htmlspecialchars($row['naam']); ?>" required>

            <label for="geboortedatum">Geboortedatum:</label>
            <input type="date" id="geboortedatum" name="geboortedatum" value="<?php echo htmlspecialchars($row['geboortedatum']); ?>" required>

            <label for="geslacht">Geslacht:</label>
            <select id="geslacht" name="geslacht" required>
                <option value="M" <?php if ($row['geslacht'] == 'M') echo 'selected'; ?>>M</option>
                <option value="V" <?php if ($row['geslacht'] == 'V') echo 'selected'; ?>>V</option>
                <option value="Overig" <?php if ($row['geslacht'] == 'Overig') echo 'selected'; ?>>Overig</option>
            </select>

            <label for="straat">Straat:</label>
            <input type="text" id="straat" name="straat" value="<?php echo htmlspecialchars($row['straat']); ?>" required>

            <label for="huisnummer">Huisnummer:</label>
            <input type="text" id="huisnummer" name="huisnummer" value="<?php echo htmlspecialchars($row['huisnummer']); ?>" required>

            <label for="postnummer">Postnummer:</label>
            <input type="text" id="postnummer" name="postnummer" value="<?php echo htmlspecialchars($row['postnummer']); ?>" required>

            <label for="plaats">Plaats:</label>
            <input type="text" id="plaats" name="plaats" value="<?php echo htmlspecialchars($row['plaats']); ?>" required>

            <label for="inschrijving">Inschrijving:</label>
            <input type="date" id="inschrijving" name="inschrijving" value="<?php echo htmlspecialchars($row['inschrijving']); ?>" required>

            <label for="uitschrijving">Uitschrijving (optioneel):</label>
            <input type="date" id="uitschrijving" name="uitschrijving" value="<?php echo htmlspecialchars($row['uitschrijving']); ?>">

            <label for="club_id">Club ID:</label>
            <input type="number" id="club_id" name="club_id" value="<?php echo htmlspecialchars($row['club_id']); ?>" required>

            <button type="submit" class="btn">Bijwerken</button>
        </form>
    </div>
</body>
</html>