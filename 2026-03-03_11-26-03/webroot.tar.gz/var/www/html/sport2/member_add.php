<?php
include 'db_connection.php'; // Zorg ervoor dat je een bestand hebt voor de databaseverbinding

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $naam = htmlspecialchars($_POST['naam']);
    $geboortedatum = htmlspecialchars($_POST['geboortedatum']);
    $geslacht = htmlspecialchars($_POST['geslacht']);
    $straat = htmlspecialchars($_POST['straat']);
    $huisnummer = htmlspecialchars($_POST['huisnummer']);
    $postnummer = htmlspecialchars($_POST['postnummer']);
    $plaats = htmlspecialchars($_POST['plaats']);
    $inschrijving = htmlspecialchars($_POST['inschrijving']);
    $uitschrijving = !empty($_POST['uitschrijving']) ? htmlspecialchars($_POST['uitschrijving']) : null;
    $club_id = htmlspecialchars($_POST['club_id']);

    $stmt = $conn->prepare("INSERT INTO leden (naam, geboortedatum, geslacht, straat, huisnummer, postnummer, plaats, inschrijving, uitschrijving, club_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssssssi", $naam, $geboortedatum, $geslacht, $straat, $huisnummer, $postnummer, $plaats, $inschrijving, $uitschrijving, $club_id);

    if ($stmt->execute()) {
        echo "<p class='success-msg'>Lid succesvol toegevoegd!</p>";
    } else {
        echo "<p class='error-msg'>Fout bij het toevoegen van lid: " . $stmt->error . "</p>";
    }

    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lid Toevoegen</title>
    <style>
        .form-container {
            max-width: 500px;
            margin: 0 auto;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .form-container label {
            display: block;
            margin-bottom: 5px;
        }
        .form-container input,
        .form-container select {
            width: 95%;
            padding: 10px;
            margin-bottom: 15px;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        .form-container button {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            background: #4CAF50;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .form-container button:hover {
            background: #45a049;
        }
        .success-msg {
            color: #2ecc71;
            font-weight: bold;
            text-align: center;
        }
        .error-msg {
            color: #e74c3c;
            font-weight: bold;
            text-align: center;
        }
    </style>
</head>
<body>
    <h2>Lid Toevoegen</h2>
    <div class="form-container">
        <form method="POST" action="index.php?view=member_add">
            <label for="naam">Naam:</label>
            <input type="text" id="naam" name="naam" required>

            <label for="geboortedatum">Geboortedatum:</label>
            <input type="date" id="geboortedatum" name="geboortedatum" required>

            <label for="geslacht">Geslacht:</label>
            <select id="geslacht" name="geslacht" required>
                <option value="M">M</option>
                <option value="V">V</option>
                <option value="Overig">Overig</option>
            </select>

            <label for="straat">Straat:</label>
            <input type="text" id="straat" name="straat" required>

            <label for="huisnummer">Huisnummer:</label>
            <input type="text" id="huisnummer" name="huisnummer" required>

            <label for="postnummer">Postnummer:</label>
            <input type="text" id="postnummer" name="postnummer" required>

            <label for="plaats">Plaats:</label>
            <input type="text" id="plaats" name="plaats" required>

            <label for="inschrijving">Inschrijving:</label>
            <input type="date" id="inschrijving" name="inschrijving" required>

            <label for="uitschrijving">Uitschrijving (optioneel):</label>
            <input type="date" id="uitschrijving" name="uitschrijving">

            <label for="club_id">Club ID:</label>
            <input type="number" id="club_id" name="club_id" required>

            <button type="submit" class="btn">Toevoegen</button>
        </form>
    </div>
</body>
</html>