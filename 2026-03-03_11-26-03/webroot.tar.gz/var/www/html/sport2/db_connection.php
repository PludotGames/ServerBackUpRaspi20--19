<?php
    $servername = "localhost";
    $username = "sport";
    $password = "sportpw";
    $dbname = "SportclubsDB";

// Maak verbinding
$conn = new mysqli($servername, $username, $password, $dbname);

// Controleer verbinding
if ($conn->connect_error) {
    die("Verbinding mislukt: " . $conn->connect_error);
}
?>