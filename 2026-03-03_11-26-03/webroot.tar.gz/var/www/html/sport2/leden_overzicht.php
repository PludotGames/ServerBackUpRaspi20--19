<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Leden Overzicht</title>
    <style>
        /* Zelfde stijl als index.php */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
        }
        nav {
            width: 200px;
            height: 100vh;
            background-color: #333;
            position: fixed;
            top: 0;
            left: 0;
            padding-top: 20px;
        }
        nav a {
            display: block;
            color: white;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }
        nav a:hover {
            background-color: #4CAF50;
        }
        .content {
            margin-left: 200px;
            padding: 20px;
            width: 100%;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 8px;
            text-align: left;
        }
    </style>
</head>
<body>
    <nav>
        <a href="index.php">Home</a>
        <a href="leden_overzicht.php">Leden Overzicht</a>
        <a href="voeg_lid_toe.php">Nieuw Lid Toevoegen</a>
        <a href="edit_member.php">Lid Aanpassen</a>
        <a href="clubs.php">Clubs</a>
    </nav>

    <div class="content">
        <h1>Leden Overzicht</h1>
        <?php
        // Database verbinding
        $servername = "localhost";
        $username = "sport";
        $password = "sportpw";
        $dbname = "SportclubsDB";

        $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {
            die("Verbinding mislukt: " . $conn->connect_error);
        }

        // Leden ophalen
        $sql = "SELECT * FROM leden";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            echo "<table><tr><th>Lid ID</th><th>Naam</th><th>Geboortedatum</th><th>Geslacht</th><th>Acties</th></tr>";
            while($row = $result->fetch_assoc()) {
                echo "<tr><td>" . $row['lid_id'] . "</td><td>" . $row['naam'] . "</td><td>" . $row['geboortedatum'] . "</td><td>" . $row['geslacht'] . "</td><td><a href='edit_member.php?lid_id=" . $row['lid_id'] . "'>Bewerken</a></td></tr>";
            }
            echo "</table>";
        } else {
            echo "Geen leden gevonden.";
        }

        $conn->close();
        ?>
    </div>
</body>
</html>
