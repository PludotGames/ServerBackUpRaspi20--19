<?php
include 'db_connection.php'; // Zorg ervoor dat je een bestand hebt voor de databaseverbinding

echo "<h2>Alle Leden</h2>";
$result = $conn->query("SELECT * FROM leden");

if ($result->num_rows > 0) {
    echo "<div class='table-container'>";
    echo "<table>";
    echo "<tr><th>Lid ID</th><th>Naam</th><th>Geboortedatum</th><th>Geslacht</th><th>Straat</th><th>Huisnummer</th><th>Postnummer</th><th>Plaats</th><th>Inschrijving</th><th>Uitschrijving</th><th>Club ID</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($row['lid_id']) . "</td>";
        echo "<td>" . htmlspecialchars($row['naam']) . "</td>";
        echo "<td>" . htmlspecialchars($row['geboortedatum']) . "</td>";
        echo "<td>" . htmlspecialchars($row['geslacht']) . "</td>";
        echo "<td>" . htmlspecialchars($row['straat']) . "</td>";
        echo "<td>" . htmlspecialchars($row['huisnummer']) . "</td>";
        echo "<td>" . htmlspecialchars($row['postnummer']) . "</td>";
        echo "<td>" . htmlspecialchars($row['plaats']) . "</td>";
        echo "<td>" . htmlspecialchars($row['inschrijving']) . "</td>";
        echo "<td>" . htmlspecialchars($row['uitschrijving']) . "</td>";
        echo "<td>" . htmlspecialchars($row['club_id']) . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    echo "</div>";
} else {
    echo "<p>Geen leden gevonden.</p>";
}
?>