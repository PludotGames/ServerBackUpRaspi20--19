<?php
include 'db_connection.php'; // Zorg ervoor dat je een bestand hebt voor de databaseverbinding

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['club_id'])) {
    // Update de club
    $club_id = htmlspecialchars($_POST['club_id']);
    $naam = htmlspecialchars($_POST['naam']);
    $locatie = htmlspecialchars($_POST['locatie']);
    $sportsoort = htmlspecialchars($_POST['sportsoort']);
    $oprichtingsjaar = htmlspecialchars($_POST['oprichtingsjaar']);
    $aantal_leden = htmlspecialchars($_POST['aantal_leden']);

    $stmt = $conn->prepare("UPDATE clubs SET naam=?, locatie=?, sportsoort=?, oprichtingsjaar=?, aantal_leden=? WHERE club_id=?");
    $stmt->bind_param("sssiii", $naam, $locatie, $sportsoort, $oprichtingsjaar, $aantal_leden, $club_id);

    if ($stmt->execute()) {
        echo "<p class='success-msg'>Club succesvol bijgewerkt!</p>";
    } else {
        echo "<p class='error-msg'>Fout bij het bijwerken van club: " . $stmt->error . "</p>";
    }

    $stmt->close();
} elseif (isset($_GET['club_id'])) {
    // Laad de gegevens van de club
    $club_id = htmlspecialchars($_GET['club_id']);
    $result = $conn->query("SELECT * FROM clubs WHERE club_id = $club_id");

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
    } else {
        echo "<p class='error-msg'>Club niet gevonden.</p>";
        exit;
    }
} else {
    // Vraag om het club_id
    echo '<h2>Club Aanpassen</h2>
            <div class="form-container" style="max-width: 500px; margin: 0 auto;">
            <form method="GET" action="index.php">
                <input type="hidden" name="view" value="club_edit">
                <label for="club_id">Club ID:</label>
                <input type="number" id="club_id" name="club_id" required>
                <button type="submit" class="btn">Zoeken</button>
            </form>
          </div>';
    exit;
}
?>

<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Club Aanpassen</title>
    <style>
        .form-container {
            max-width: 500px;
            margin: 0 auto;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .form-container label {
            display: block;
            margin-bottom: 5px;
        }
        .form-container input,
        .form-container select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        .form-container button {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            background: #4CAF50;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .form-container button:hover {
            background: #45a049;
        }
        .success-msg {
            color: #2ecc71;
            font-weight: bold;
            text-align: center;
        }
        .error-msg {
            color: #e74c3c;
            font-weight: bold;
            text-align: center;
        }
    </style>
</head>
<body>
    <h2>Club Aanpassen</h2>
    <div class="form-container">
        <form method="POST" action="index.php?view=club_edit">
            <input type="hidden" name="club_id" value="<?php echo htmlspecialchars($row['club_id']); ?>">

            <label for="naam">Naam:</label>
            <input type="text" id="naam" name="naam" value="<?php echo htmlspecialchars($row['naam']); ?>" required>

            <label for="locatie">Locatie:</label>
            <input type="text" id="locatie" name="locatie" value="<?php echo htmlspecialchars($row['locatie']); ?>" required>

            <label for="sportsoort">Sportsoort:</label>
            <input type="text" id="sportsoort" name="sportsoort" value="<?php echo htmlspecialchars($row['sportsoort']); ?>" required>

            <label for="oprichtingsjaar">Oprichtingsjaar:</label>
            <input type="number" id="oprichtingsjaar" name="oprichtingsjaar" value="<?php echo htmlspecialchars($row['oprichtingsjaar']); ?>" required>

            <label for="aantal_leden">Aantal Leden:</label>
            <input type="number" id="aantal_leden" name="aantal_leden" value="<?php echo htmlspecialchars($row['aantal_leden']); ?>" required>

            <button type="submit" class="btn">Bijwerken</button>
        </form>
    </div>
</body>
</html>