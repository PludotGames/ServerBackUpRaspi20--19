<?php
include 'db_connection.php'; // Zorg ervoor dat je een bestand hebt voor de databaseverbinding

echo "<h2>Alle Leden gesorteerd per club id</h2>";
$result = $conn->query("SELECT * FROM leden ORDER BY club_id ASC");
if ($result->num_rows > 0) {
    echo "<div class='table-container'><table>";
    echo "<tr>
            <th>Lid ID</th>
            <th>Naam</th>
            <th>Geboortedatum</th>
            <th>Geslacht</th>
            <th>Straat</th>
            <th>Huisnummer</th>
            <th>Postnummer</th>
            <th>Plaats</th>
            <th>Inschrijving</th>
            <th>Uitschrijving</th>
            <th>Club ID</th>
            </tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>" . htmlspecialchars($row['lid_id']) . "</td>
                <td>" . htmlspecialchars($row['naam']) . "</td>
                <td>" . htmlspecialchars($row['geboortedatum']) . "</td>
                <td>" . htmlspecialchars($row['geslacht']) . "</td>
                <td>" . htmlspecialchars($row['straat']) . "</td>
                <td>" . htmlspecialchars($row['huisnummer']) . "</td>
                <td>" . htmlspecialchars($row['postnummer']) . "</td>
                <td>" . htmlspecialchars($row['plaats']) . "</td>
                <td>" . htmlspecialchars($row['inschrijving']) . "</td>
                <td>" . htmlspecialchars($row['uitschrijving']) . "</td>
                <td>" . htmlspecialchars($row['club_id']) . "</td>
                </tr>";
    }
    echo "</table></div>";
} else {
    echo "<p class='error-msg'>Geen leden gevonden.</p>";
}
?>