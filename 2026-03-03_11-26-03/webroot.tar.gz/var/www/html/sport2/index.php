<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SportclubsDB</title>
    <link rel="stylesheet" href="style.css"> <!-- Zorg ervoor dat je CSS-bestand correct is gekoppeld -->
</head>
<body>
    <div class="sidebar">
        <a href="index.php?view=home"><img src="Logo-SportclubsDatabase.png" alt="Sportclubs DB" width="190"></a>
        <a href="index.php?view=home">Home</a>
        <a href="index.php?view=members_all">Alle Leden</a>
        <a href="index.php?view=members_by_location">Leden per Locatie</a>
        <a href="index.php?view=members_by_club_id">Leden per Club ID</a>
        <a href="index.php?view=clubs_all">Alle Clubs</a>
        <a href="index.php?view=member_add">Lid Toevoegen</a>
        <a href="index.php?view=club_add">Club Toevoegen</a>
        <a href="index.php?view=member_edit">Lid Aanpassen</a>
        <a href="index.php?view=club_edit">Club Aanpassen</a>
        <a href="index.php?view=update_club_members">Update Aantal Leden per Club</a>
    </div>

    <div class="content">
        <?php
        include 'db_connection.php'; // Zorg ervoor dat je een bestand hebt voor de databaseverbinding

        if (isset($_GET['view'])) {
            $view = htmlspecialchars($_GET['view']);
            switch ($view) {
                case "home":
                    echo "<h1>Welkom bij SportclubsDB</h1>";
                    echo "<h2>Over SportclubsDB</h2>";
                    echo "<p>SportclubsDB is een uitgebreide database die alle Vlaamse sportclubs omvat die verzekerd zijn bij SCDB-assurance. Deze database biedt een centraal platform waar sportliefhebbers en organisaties gemakkelijk informatie kunnen vinden over diverse sportclubs in Vlaanderen.</p>";
                    echo "<h3>Wat kun je vinden?</h3>";
                    echo "<p>Of je nu op zoek bent naar een voetbalclub, een tennisvereniging of een zwemteam, SportclubsDB helpt je de juiste club te vinden die past bij jouw interesses en behoeften.</p>";
                    echo "<h3>Waarom kiezen voor SportclubsDB?</h3>";
                    echo "<p>Dankzij de verzekering bij SCDB-assurance kunnen leden met een gerust hart deelnemen aan sportactiviteiten, wetende dat ze goed beschermd zijn.</p>";
                    break;
                case "members_all":
                    include 'members_all.php';
                    break;
                case "members_by_location":
                    include 'members_by_location.php';
                    break;
                case "members_by_club_id":
                    include 'members_by_club_id.php';
                    break;
                case "clubs_all":
                    include 'clubs_all.php';
                    break;
                case "member_add":
                    include 'member_add.php';
                    break;
                case "club_add":
                    include 'club_add.php';
                    break;
                case "member_edit":
                    include 'member_edit.php';
                    break;
                case "club_edit":
                    include 'club_edit.php';
                    break;
                case "update_club_members":
                    include 'update_club_members.php';
                    break;
                default:
                    echo "<p>Pagina niet gevonden.</p>";
            }
        } else {
            echo "<h1>Welkom bij SportclubsDB</h1>";
            echo "<h2>Over SportclubsDB</h2>";
            echo "<p>SportclubsDB is een uitgebreide database die alle Vlaamse sportclubs omvat die verzekerd zijn bij SCDB-assurance. Deze database biedt een centraal platform waar sportliefhebbers en organisaties gemakkelijk informatie kunnen vinden over diverse sportclubs in Vlaanderen.</p>";
            echo "<h3>Wat kun je vinden?</h3>";
            echo "<p>Of je nu op zoek bent naar een voetbalclub, een tennisvereniging of een zwemteam, SportclubsDB helpt je de juiste club te vinden die past bij jouw interesses en behoeften.</p>";
            echo "<h3>Waarom kiezen voor SportclubsDB?</h3>";
            echo "<p>Dankzij de verzekering bij SCDB-assurance kunnen leden met een gerust hart deelnemen aan sportactiviteiten, wetende dat ze goed beschermd zijn.</p>";
        }
        ?>
    </div>
</body>
</html>
