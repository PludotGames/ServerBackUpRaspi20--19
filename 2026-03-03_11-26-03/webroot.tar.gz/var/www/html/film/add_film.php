<?php include 'menu.php'; ?>
<?php
include 'db_connection.php'; // Verbind met de database

$message = "";

// Verwerk het formulier als het is ingediend
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $titel = $_POST['titel'] ?? '';
    $genre = $_POST['genre'] ?? '';
    $duur = $_POST['duur'] ?? 0;
    $releasejaar = $_POST['releasejaar'] ?? '';

    // Validatie
    if (!empty($titel) && !empty($genre) && $duur > 0 && !empty($releasejaar)) {
        try {
            $query = "INSERT INTO films (titel, genre, duur, releasejaar) VALUES (:titel, :genre, :duur, :releasejaar)";
            $stmt = $conn->prepare($query);
            $stmt->execute([
                ':titel' => $titel,
                ':genre' => $genre,
                ':duur' => $duur,
                ':releasejaar' => $releasejaar,
            ]);
            $message = "Film succesvol toegevoegd!";
        } catch (PDOException $e) {
            $message = "Fout bij het toevoegen van de film: " . htmlspecialchars($e->getMessage());
        }
    } else {
        $message = "Alle velden moeten correct worden ingevuld.";
    }
}
?>

<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Film Toevoegen</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            text-align: center;
        }
        .form-container {
            width: 800px;
            margin: 20px auto;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 8px;
            background-color: #dddddd;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        select, input[type="text"], input[type="number"], button {
            width: 80%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        button {
            background-color: #007BFF;
            color: white;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
        .message {
            margin-top: 10px;
            color: green;
        }
        .error {
            margin-top: 10px;
            color: red;
        }
    </style>
</head>
<body>
    <h1>Film Toevoegen</h1>
    <div class="form-container">
        <?php if ($message): ?>
            <p class="<?= strpos($message, 'Fout') === false ? 'message' : 'error' ?>">
                <?= htmlspecialchars($message) ?>
            </p>
        <?php endif; ?>
        <form method="POST" action="add_film.php">
            <label>Titel:</label><br>
            <input type="text" name="titel" required><br>
            <label>Genre:</label><br>
            <select name="genre" required>
                <option value="">-- Kies een genre --</option>
                <option value="Actie">Actie</option>
                <option value="Animatie">Animatie</option>
                <option value="Avontuur">Avontuur</option>
                <option value="Biografie">Biografie</option>
                <option value="Drama">Drama</option>
                <option value="Fantasy">Fantasy</option>
                <option value="Historisch">Historisch</option>
                <option value="Horror">Horror</option>
                <option value="Komedie">Komedie</option>
                <option value="Misdaad">Misdaad</option>
                <option value="Musical">Musical</option>
                <option value="Oorlog">Oorlog</option>
                <option value="Romantiek">Romantiek</option>
                <option value="Science Fiction">Science Fiction</option>
                <option value="Thriller">Thriller</option>
                <option value="Western">Western</option>
            </select><br>
            <label>Duur (minuten):</label><br>
            <input type="number" name="duur" min="1" required><br>
            <label>Releasejaar:</label><br>
            <input type="number" name="releasejaar" min="1900" max="<?= date('Y') ?>" required><br>
            <button type="submit">Toevoegen</button>
        </form>
    </div>
</body>
</html>
