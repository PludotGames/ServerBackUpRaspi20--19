<?php include 'menu.php'; ?>
<?php
include 'db_connection.php'; // Verbind met de database

$message = "";
$review = null;

// Stap 1: Haal een lijst van alle reviews op
try {
    $query = "
        SELECT reviews.review_id, reviews.gebruikersnaam, reviews.beoordeling, reviews.commentaar, films.titel 
        FROM reviews
        JOIN films ON reviews.film_id = films.film_id
        ORDER BY films.titel ASC";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $reviews = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "<p>Fout bij het ophalen van reviews: " . htmlspecialchars($e->getMessage()) . "</p>";
    die();
}

// Stap 2: Als een review is geselecteerd, haal de details op
if (isset($_GET['review_id'])) {
    try {
        $query = "SELECT * FROM reviews WHERE review_id = :review_id";
        $stmt = $conn->prepare($query);
        $stmt->execute([':review_id' => $_GET['review_id']]);
        $review = $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        echo "<p>Fout bij het ophalen van reviewgegevens: " . htmlspecialchars($e->getMessage()) . "</p>";
        die();
    }
}

// Stap 3: Verwerk het formulier als er wijzigingen worden ingediend
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['review_id'])) {
    $review_id = $_POST['review_id'];
    $gebruikersnaam = $_POST['gebruikersnaam'];
    $beoordeling = $_POST['beoordeling'];
    $commentaar = $_POST['commentaar'];

    // Validatie
    if (!empty($gebruikersnaam) && $beoordeling >= 1 && $beoordeling <= 10 && !empty($commentaar)) {
        try {
            $query = "UPDATE reviews SET gebruikersnaam = :gebruikersnaam, beoordeling = :beoordeling, commentaar = :commentaar WHERE review_id = :review_id";
            $stmt = $conn->prepare($query);
            $stmt->execute([
                ':gebruikersnaam' => $gebruikersnaam,
                ':beoordeling' => $beoordeling,
                ':commentaar' => $commentaar,
                ':review_id' => $review_id
            ]);
            $message = "Review succesvol aangepast!";
        } catch (PDOException $e) {
            $message = "Fout bij het aanpassen van de review: " . htmlspecialchars($e->getMessage());
        }
    } else {
        $message = "Alle velden moeten correct worden ingevuld.";
    }
}
?>

<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Review Aanpassen</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            text-align: center;
        }
        .form-container {
            width: 800px;
            margin: 20px auto;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 8px;
            background-color: #dddddd;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        select, input[type="text"], input[type="number"], textarea, button {
            width: 80%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        textarea {
            height: 100px;
        }
        button {
            background-color: #007BFF;
            color: white;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
        .message {
            margin-top: 10px;
            color: green;
        }
        .error {
            margin-top: 10px;
            color: red;
        }
    </style>
</head>
<body>
    <h1>Review Aanpassen</h1>
    <div class="form-container">
        <?php if ($message): ?>
            <p class="<?= strpos($message, 'Fout') === false ? 'message' : 'error' ?>">
                <?= htmlspecialchars($message) ?>
            </p>
        <?php endif; ?>

        <!-- Dropdown om een review te kiezen -->
        <form method="GET" action="edit_review.php">
            <label for="review_id">Kies een review om aan te passen:</label><br>
            <select name="review_id" id="review_id" onchange="this.form.submit()">
                <option value="">-- Selecteer een review --</option>
                <?php foreach ($reviews as $r): ?>
                    <option value="<?= $r['review_id'] ?>" <?= (isset($_GET['review_id']) && $_GET['review_id'] == $r['review_id']) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($r['titel']) ?> - <?= htmlspecialchars($r['gebruikersnaam']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </form>

        <!-- Formulier voor het aanpassen -->
        <?php if ($review): ?>
            <form method="POST" action="edit_review.php">
                <input type="hidden" name="review_id" value="<?= htmlspecialchars($review['review_id']) ?>">
                <label>Gebruikersnaam:</label><br>
                <input type="text" name="gebruikersnaam" value="<?= htmlspecialchars($review['gebruikersnaam']) ?>" required><br>
                <label>Beoordeling (1-10):</label><br>
                <input type="number" name="beoordeling" value="<?= htmlspecialchars($review['beoordeling']) ?>" min="1" max="10" required><br>
                <label>Commentaar:</label><br>
                <textarea name="commentaar" required><?= htmlspecialchars($review['commentaar']) ?></textarea><br>
                <button type="submit">Aanpassen</button>
            </form>
        <?php endif; ?>
    </div>
</body>
</html>

