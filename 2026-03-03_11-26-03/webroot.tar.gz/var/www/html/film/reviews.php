 <?php include 'menu.php'; ?>
<?php
include 'db_connection.php'; // Verbind met de database

// Haal alle reviews op met de bijbehorende film
try {
    $query = "
        SELECT films.titel AS film_titel, 
               reviews.gebruikersnaam, 
               reviews.beoordeling, 
               reviews.commentaar 
        FROM reviews
        INNER JOIN films ON reviews.film_id = films.film_id
        ORDER BY reviews.beoordeling DESC";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $reviews = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "Fout bij het ophalen van reviews: " . htmlspecialchars($e->getMessage());
    die();
}
?>

<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reviews Overzicht</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            text-align: center;
        }
        .table-container {
            width: 800px;
            margin: 20px auto;
            border: 1px solid #ddd;
            border-radius: 8px;
            background-color: #ffffff;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table th, table td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }
        table th {
            background-color: #f4f4f4;
        }
        table tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        table tr:nth-child(odd) {
            background-color: #ffffff;
        }
        table tr:hover {
            background-color: #f1f1f1;
        }
        h1 {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <h1>Reviews Overzicht</h1>
    <div class="table-container">
        <?php if (count($reviews) > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>Film</th>
                        <th>Gebruikersnaam</th>
                        <th>Beoordeling</th>
                        <th>Commentaar</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($reviews as $review): ?>
                    <tr>
                        <td><?= htmlspecialchars($review['film_titel']) ?></td>
                        <td><?= htmlspecialchars($review['gebruikersnaam']) ?></td>
                        <td><?= htmlspecialchars($review['beoordeling']) ?></td>
                        <td><?= htmlspecialchars($review['commentaar']) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>Geen reviews gevonden in de database.</p>
        <?php endif; ?>
    </div>
</body>
</html>
