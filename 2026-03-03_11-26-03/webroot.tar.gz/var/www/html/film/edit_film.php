<?php include 'menu.php'; ?>
<?php
include 'db_connection.php'; // Verbind met de database

$message = "";
$film = null;

// Stap 1: Haal een lijst van alle films op
try {
    $query = "SELECT * FROM films ORDER BY titel ASC";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $films = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "<p>Fout bij het ophalen van films: " . htmlspecialchars($e->getMessage()) . "</p>";
    die();
}

// Stap 2: Als een film is geselecteerd, haal de details op
if (isset($_GET['film_id'])) {
    try {
        $query = "SELECT * FROM films WHERE film_id = :film_id";
        $stmt = $conn->prepare($query);
        $stmt->execute([':film_id' => $_GET['film_id']]);
        $film = $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        echo "<p>Fout bij het ophalen van filmgegevens: " . htmlspecialchars($e->getMessage()) . "</p>";
        die();
    }
}

// Stap 3: Verwerk het formulier als er wijzigingen worden ingediend
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['film_id'])) {
    $film_id = $_POST['film_id'];
    $titel = $_POST['titel'];
    $genre = $_POST['genre'];
    $duur = $_POST['duur'];
    $releasejaar = $_POST['releasejaar'];

    // Validatie
    if (!empty($titel) && !empty($genre) && $duur > 0 && !empty($releasejaar)) {
        try {
            $query = "UPDATE films SET titel = :titel, genre = :genre, duur = :duur, releasejaar = :releasejaar WHERE film_id = :film_id";
            $stmt = $conn->prepare($query);
            $stmt->execute([
                ':titel' => $titel,
                ':genre' => $genre,
                ':duur' => $duur,
                ':releasejaar' => $releasejaar,
                ':film_id' => $film_id
            ]);
            $message = "Film succesvol aangepast!";
        } catch (PDOException $e) {
            $message = "Fout bij het aanpassen van de film: " . htmlspecialchars($e->getMessage());
        }
    } else {
        $message = "Alle velden moeten correct worden ingevuld.";
    }
}
?>

<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Film Aanpassen</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            text-align: center;
        }
        .form-container {
            width: 800px;
            margin: 20px auto;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 8px;
            background-color: #dddddd;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        select, input[type="text"], input[type="number"], button {
            width: 80%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        button {
            background-color: #007BFF;
            color: white;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
        .message {
            margin-top: 10px;
            color: green;
        }
        .error {
            margin-top: 10px;
            color: red;
        }
    </style>
</head>
<body>
    <h1>Film Aanpassen</h1>
    <div class="form-container">
        <!-- Feedbackbericht -->
        <?php if ($message): ?>
            <p class="<?= strpos($message, 'Fout') === false ? 'message' : 'error' ?>">
                <?= htmlspecialchars($message) ?>
            </p>
        <?php endif; ?>

        <!-- Dropdownmenu om een film te kiezen -->
        <form method="GET" action="edit_film.php">
            <label for="film_id">Kies een film om aan te passen:</label><br>
            <select name="film_id" id="film_id" onchange="this.form.submit()">
                <option value="">-- Selecteer een film --</option>
                <?php foreach ($films as $f): ?>
                    <option value="<?= $f['film_id'] ?>" <?= (isset($_GET['film_id']) && $_GET['film_id'] == $f['film_id']) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($f['titel']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </form>

        <!-- Formulier om de filmgegevens aan te passen -->
        <?php if ($film): ?>
            <form method="POST" action="edit_film.php">
                <input type="hidden" name="film_id" value="<?= htmlspecialchars($film['film_id']) ?>">
                <label>Titel:</label><br>
                <input type="text" name="titel" value="<?= htmlspecialchars($film['titel']) ?>" required><br>
                <label>Genre:</label><br>
                <select name="genre" required>
                    <option value="">-- Kies een genre --</option>
                    <option value="Actie" <?= $film['genre'] === 'Actie' ? 'selected' : '' ?>>Actie</option>
                    <option value="Animatie" <?= $film['genre'] === 'Animatie' ? 'selected' : '' ?>>Animatie</option>
                    <option value="Avontuur" <?= $film['genre'] === 'Avontuur' ? 'selected' : '' ?>>Avontuur</option>
                    <option value="Biografie" <?= $film['genre'] === 'Biografie' ? 'selected' : '' ?>>Biografie</option>
                    <option value="Drama" <?= $film['genre'] === 'Drama' ? 'selected' : '' ?>>Drama</option>
                    <option value="Fantasy" <?= $film['genre'] === 'Fantasy' ? 'selected' : '' ?>>Fantasy</option>
                    <option value="Historisch" <?= $film['genre'] === 'Historisch' ? 'selected' : '' ?>>Historisch</option>
                    <option value="Horror" <?= $film['genre'] === 'Horror' ? 'selected' : '' ?>>Horror</option>
                    <option value="Komedie" <?= $film['genre'] === 'Komedie' ? 'selected' : '' ?>>Komedie</option>
                    <option value="Misdaad" <?= $film['genre'] === 'Misdaad' ? 'selected' : '' ?>>Misdaad</option>
                    <option value="Musical" <?= $film['genre'] === 'Musical' ? 'selected' : '' ?>>Musical</option>
                    <option value="Oorlog" <?= $film['genre'] === 'Oorlog' ? 'selected' : '' ?>>Oorlog</option>
                    <option value="Romantiek" <?= $film['genre'] === 'Romantiek' ? 'selected' : '' ?>>Romantiek</option>
                    <option value="Science Fiction" <?= $film['genre'] === 'Science Fiction' ? 'selected' : '' ?>>Science Fiction</option>
                    <option value="Thriller" <?= $film['genre'] === 'Thriller' ? 'selected' : '' ?>>Thriller</option>
                    <option value="Western" <?= $film['genre'] === 'Western' ? 'selected' : '' ?>>Western</option>
                </select><br>
                <label>Duur (minuten):</label><br>
                <input type="number" name="duur" value="<?= htmlspecialchars($film['duur']) ?>" min="1" required><br>
                <label>Releasejaar:</label><br>
                <input type="number" name="releasejaar" value="<?= htmlspecialchars($film['releasejaar']) ?>" min="1900" max="<?= date('Y') ?>" required><br>
                <button type="submit">Aanpassen</button>
            </form>
        <?php endif; ?>
    </div>
</body>
</html>
