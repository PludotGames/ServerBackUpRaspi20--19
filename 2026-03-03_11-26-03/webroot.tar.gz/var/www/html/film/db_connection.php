<?php
$host = 'localhost';
$dbname = 'filmDB';
$username = 'film';
$password = 'filmpw';

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    // Stel de PDO-foutmodus in op Exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Database verbinding mislukt: " . $e->getMessage();
    die();
}
?>
