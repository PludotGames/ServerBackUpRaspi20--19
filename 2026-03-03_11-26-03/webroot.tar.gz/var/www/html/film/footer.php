<footer style="text-align: center; margin-top: 20px;">
    <p>&copy; <?= date("Y") ?> Filmbeheer. Alle rechten voorbehouden.</p>
</footer>
