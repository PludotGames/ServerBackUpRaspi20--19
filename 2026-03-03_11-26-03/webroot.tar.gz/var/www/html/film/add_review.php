<?php include 'menu.php'; ?>
<?php
include 'db_connection.php'; // Verbind met de database

$message = "";

// Stap 1: Haal een lijst van alle films op
try {
    $query = "SELECT * FROM films ORDER BY titel ASC";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $films = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "<p>Fout bij het ophalen van films: " . htmlspecialchars($e->getMessage()) . "</p>";
    die();
}

// Stap 2: Verwerk het formulier als het is ingediend
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $film_id = $_POST['film_id'] ?? '';
    $gebruikersnaam = $_POST['gebruikersnaam'] ?? '';
    $beoordeling = $_POST['beoordeling'] ?? '';
    $commentaar = $_POST['commentaar'] ?? '';

    // Validatie
    if (!empty($film_id) && !empty($gebruikersnaam) && $beoordeling >= 1 && $beoordeling <= 10 && !empty($commentaar)) {
        try {
            $query = "INSERT INTO reviews (film_id, gebruikersnaam, beoordeling, commentaar) VALUES (:film_id, :gebruikersnaam, :beoordeling, :commentaar)";
            $stmt = $conn->prepare($query);
            $stmt->execute([
                ':film_id' => $film_id,
                ':gebruikersnaam' => $gebruikersnaam,
                ':beoordeling' => $beoordeling,
                ':commentaar' => $commentaar,
            ]);
            $message = "Review succesvol toegevoegd!";
        } catch (PDOException $e) {
            $message = "Fout bij het toevoegen van de review: " . htmlspecialchars($e->getMessage());
        }
    } else {
        $message = "Alle velden moeten correct worden ingevuld.";
    }
}
?>

<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Review Toevoegen</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            text-align: center;
        }
        .form-container {
            width: 800px;
            margin: 20px auto;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 8px;
            background-color: #dddddd;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        select, input[type="text"], input[type="number"], textarea, button {
            width: 80%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        textarea {
            height: 100px;
        }
        button {
            background-color: #007BFF;
            color: white;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
        .message {
            margin-top: 10px;
            color: green;
        }
        .error {
            margin-top: 10px;
            color: red;
        }
    </style>
</head>
<body>
    <h1>Review Toevoegen</h1>
    <div class="form-container">
        <?php if ($message): ?>
            <p class="<?= strpos($message, 'Fout') === false ? 'message' : 'error' ?>">
                <?= htmlspecialchars($message) ?>
            </p>
        <?php endif; ?>
        <form method="POST" action="add_review.php">
            <label>Film:</label><br>
            <select name="film_id" required>
                <option value="">-- Kies een film --</option>
                <?php foreach ($films as $film): ?>
                    <option value="<?= $film['film_id'] ?>"><?= htmlspecialchars($film['titel']) ?></option>
                <?php endforeach; ?>
            </select><br>
            <label>Gebruikersnaam:</label><br>
            <input type="text" name="gebruikersnaam" required><br>
            <label>Beoordeling (1-10):</label><br>
            <input type="number" name="beoordeling" min="1" max="10" required><br>
            <label>Commentaar:</label><br>
            <textarea name="commentaar" required></textarea><br>
            <button type="submit">Toevoegen</button>
        </form>
    </div>
</body>
</html>
