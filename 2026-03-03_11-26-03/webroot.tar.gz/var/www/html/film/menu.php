<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Filmbeheer</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        nav {
            background-color: #333;
            padding: 15px;
            display: flex;
            justify-content: center;
        }
        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            position: relative;
        }
        nav ul li {
            display: inline-block;
            position: relative;
        }
        nav ul li a {
            color: white;
            text-decoration: none;
            padding: 10px 20px;
            display: block;
        }
        nav ul li a:hover {
            background-color: #575757;
        }
        nav ul li:hover > ul {
            display: block;
        }
        nav ul ul {
            display: none;
            position: absolute;
            background-color: #333;
            padding: 0;
            margin: 0;
            z-index: 1000;
            min-width: 200px;
            border-radius: 5px;
        }
        nav ul ul li {
            display: block;
            text-align: left;
        }
        nav ul ul li a {
            padding: 10px 20px;
        }
        nav ul ul li a:hover {
            background-color: #575757;
        }
    </style>
</head>
<body>
    <nav>
        <ul>
            <li>
                <a href="index.php">Dashboard</a>
            </li>
            <li>
                <a href="#">Films</a>
                <ul>
                    <li><a href="films.php">Film Overzicht</a></li>
                    <li><a href="add_film.php">Film Toevoegen</a></li>
                    <li><a href="edit_film.php">Film Aanpassen</a></li>
                </ul>
            </li>
            <li>
                <a href="#">Reviews</a>
                <ul>
                    <li><a href="reviews.php">Review Overzicht</a></li>
                    <li><a href="add_review.php">Review Toevoegen</a></li>
                    <li><a href="edit_review.php">Review Aanpassen</a></li>
                </ul>
            </li>
           <li>
                <a href="#">Extra's</a>
                <ul>
                    <li><a href="filmsTop20.php">Films Top 20</a></li>
                    <li><a href="filmsjoinreview.php">Films met reviews</a></li>
                    <li><a href="filmsSortDuurtijd.php">Films gesorteerd op
                    duurtijd</a></li>
                    <li><a href="films_alphabetisch.php">Films op alphabetische
                    volgorde</a></li>


                </ul>
            </li>
        </ul>
    </nav>
</body>
</html>
