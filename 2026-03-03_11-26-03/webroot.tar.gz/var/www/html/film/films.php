<?php
include 'menu.php'; // Navigatiemenu
include 'db_connection.php'; // Verbind met de database

// Haal alle films op uit de database
try {
    $query = "SELECT * FROM films ORDER BY titel;";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $films = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "<p>Fout bij het ophalen van films: " . htmlspecialchars($e->getMessage()) . "</p>";
    die();
}
?>

<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Films Overzicht</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            text-align: center;
        }
        .table-container {
            width: 800px;
            margin: 20px auto;
            border: 1px solid #ddd;
            border-radius: 8px;
            background-color: #ffffff;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table th, table td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }
        table th {
            background-color: #f4f4f4;
        }
        table tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        table tr:nth-child(odd) {
            background-color: #ffffff;
        }
        table tr:hover {
            background-color: #f1f1f1;
        }
        h1 {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <h1>Films Overzicht</h1>
    <div class="table-container">
        <?php if (count($films) > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>Titel</th>
                        <th>Genre</th>
                        <th>Duur (min)</th>
                        <th>Releasejaar</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($films as $film): ?>
                    <tr>
                        <td><?= htmlspecialchars($film['titel']) ?></td>
                        <td><?= htmlspecialchars($film['genre']) ?></td>
                        <td><?= htmlspecialchars($film['duur']) ?></td>
                        <td><?= htmlspecialchars($film['releasejaar']) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>Geen films gevonden in de database.</p>
        <?php endif; ?>
    </div>
</body>
</html>
