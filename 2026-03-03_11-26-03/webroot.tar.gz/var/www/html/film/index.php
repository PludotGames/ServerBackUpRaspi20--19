<?php
include 'db_connection.php'; // Verbind met de database

// Haal het totaal aantal films op
try {
    $filmQuery = "SELECT COUNT(*) AS total_films FROM films";
    $stmtFilms = $conn->prepare($filmQuery);
    $stmtFilms->execute();
    $totalFilms = $stmtFilms->fetch(PDO::FETCH_ASSOC)['total_films'];
} catch (PDOException $e) {
    $totalFilms = "Onbekend";
}

// Haal het totaal aantal reviews op
try {
    $reviewQuery = "SELECT COUNT(*) AS total_reviews FROM reviews";
    $stmtReviews = $conn->prepare($reviewQuery);
    $stmtReviews->execute();
    $totalReviews = $stmtReviews->fetch(PDO::FETCH_ASSOC)['total_reviews'];
} catch (PDOException $e) {
    $totalReviews = "Onbekend";
}

// Haal aantal films per genre op
try {
    $genreQuery = "SELECT genre, COUNT(*) AS aantal FROM films GROUP BY genre ORDER BY aantal DESC";
    $stmtGenre = $conn->prepare($genreQuery);
    $stmtGenre->execute();
    $genreData = $stmtGenre->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $genreData = [];
}

// Haal aantal reviews per genre op (voor de grafiek)
try {
    $reviewsPerGenreQuery = "
        SELECT f.genre, COUNT(r.review_id) AS aantal_reviews 
        FROM films f 
        LEFT JOIN reviews r ON f.film_id = r.film_id 
        GROUP BY f.genre 
        ORDER BY aantal_reviews DESC
    ";
    $stmtReviewsGenre = $conn->prepare($reviewsPerGenreQuery);
    $stmtReviewsGenre->execute();
    $reviewsPerGenre = $stmtReviewsGenre->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $reviewsPerGenre = [];
}

// Haal gemiddelde beoordeling op
try {
    $avgQuery = "SELECT ROUND(AVG(beoordeling), 1) AS gemiddelde FROM reviews";
    $stmtAvg = $conn->prepare($avgQuery);
    $stmtAvg->execute();
    $gemiddeldeBeoordeling = $stmtAvg->fetch(PDO::FETCH_ASSOC)['gemiddelde'];
} catch (PDOException $e) {
    $gemiddeldeBeoordeling = "Onbekend";
}

// Haal top 5 best beoordeelde films op
try {
    $topFilmsQuery = "
        SELECT f.titel, ROUND(AVG(r.beoordeling), 1) AS gem_beoordeling, COUNT(r.review_id) AS aantal_reviews
        FROM films f
        INNER JOIN reviews r ON f.film_id = r.film_id
        GROUP BY f.film_id, f.titel
        HAVING aantal_reviews >= 2
        ORDER BY gem_beoordeling DESC, aantal_reviews DESC
        LIMIT 5
    ";
    $stmtTopFilms = $conn->prepare($topFilmsQuery);
    $stmtTopFilms->execute();
    $topFilms = $stmtTopFilms->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $topFilms = [];
}

// Haal aantal unieke gebruikers op
try {
    $usersQuery = "SELECT COUNT(DISTINCT gebruikersnaam) AS total_users FROM reviews";
    $stmtUsers = $conn->prepare($usersQuery);
    $stmtUsers->execute();
    $totalUsers = $stmtUsers->fetch(PDO::FETCH_ASSOC)['total_users'];
} catch (PDOException $e) {
    $totalUsers = "Onbekend";
}

// Haal nieuwste films op (top 5)
try {
    $nieuwsteQuery = "SELECT titel, releasejaar, genre FROM films ORDER BY releasejaar DESC LIMIT 5";
    $stmtNieuwste = $conn->prepare($nieuwsteQuery);
    $stmtNieuwste->execute();
    $nieuwsteFilms = $stmtNieuwste->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $nieuwsteFilms = [];
}
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Filmbeheer Dashboard</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
        }
        nav {
            background-color: #333;
            padding: 15px;
            display: flex;
            justify-content: center;
        }
        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            position: relative;
        }
        nav ul li {
            display: inline-block;
            position: relative;
        }
        nav ul li a {
            color: white;
            text-decoration: none;
            padding: 10px 20px;
            display: block;
        }
        nav ul li a:hover {
            background-color: #575757;
        }
        nav ul li:hover > ul {
            display: block;
        }
        nav ul ul {
            display: none;
            position: absolute;
            background-color: #333;
            padding: 0;
            margin: 0;
            z-index: 1000;
            min-width: 200px;
            border-radius: 5px;
        }
        nav ul ul li {
            display: block;
            text-align: left;
        }
        nav ul ul li a {
            padding: 10px 20px;
        }
        nav ul ul li a:hover {
            background-color: #575757;
        }
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
        }
        h1 {
            text-align: center;
            color: #333;
            margin: 30px 0;
            font-size: 2.5em;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            text-align: center;
            transition: transform 0.3s;
        }
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
        }
        .stat-number {
            font-size: 2.5em;
            font-weight: bold;
            color: #4CAF50;
            margin: 10px 0;
        }
        .stat-label {
            color: #666;
            font-size: 1.1em;
        }
        .dashboard-section {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .dashboard-section h2 {
            color: #333;
            margin-bottom: 20px;
            border-bottom: 3px solid #4CAF50;
            padding-bottom: 10px;
        }
        .genre-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
            gap: 15px;
            margin-top: 15px;
        }
        .genre-item {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 15px;
            border-radius: 8px;
            text-align: center;
        }
        .genre-name {
            font-weight: bold;
            margin-bottom: 5px;
        }
        .genre-count {
            font-size: 1.8em;
            font-weight: bold;
        }
        .chart-container {
            position: relative;
            height: 400px;
            margin-top: 20px;
        }
        .top-films-list {
            list-style: none;
        }
        .top-films-list li {
            padding: 15px;
            margin: 10px 0;
            background: #f9f9f9;
            border-left: 4px solid #4CAF50;
            border-radius: 5px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .film-title {
            font-weight: bold;
            color: #333;
        }
        .film-rating {
            background: #4CAF50;
            color: white;
            padding: 5px 15px;
            border-radius: 20px;
            font-weight: bold;
        }
        .two-column {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }
        footer {
            text-align: center;
            margin-top: 40px;
            padding: 20px;
            color: #666;
            font-size: 14px;
        }
        @media (max-width: 768px) {
            .two-column {
                grid-template-columns: 1fr;
            }
            h1 {
                font-size: 1.8em;
            }
        }
    </style>
</head>
<body>
    <nav>
        <ul>
            <li><a href="index.php">Dashboard</a></li>
            <li>
                <a href="#">Films</a>
                <ul>
                    <li><a href="films.php">Film Overzicht</a></li>
                    <li><a href="add_film.php">Film Toevoegen</a></li>
                    <li><a href="edit_film.php">Film Aanpassen</a></li>
                </ul>
            </li>
            <li>
                <a href="#">Reviews</a>
                <ul>
                    <li><a href="reviews.php">Review Overzicht</a></li>
                    <li><a href="add_review.php">Review Toevoegen</a></li>
                    <li><a href="edit_review.php">Review Aanpassen</a></li>
                </ul>
            </li>
            <li>
                <a href="#">Extra's</a>
                <ul>
                    <li><a href="filmsTop10.php">Films Top 10</a></li>
                    <li><a href="filmsjoinreview.php">Films met reviews</a></li>
                    <li><a href="filmsSortDuurtijd.php">Films gesorteerd op duurtijd</a></li>
                </ul>
            </li>
        </ul>
    </nav>
    
    <div class="container">
        <h1>Filmbeheer Dashboard</h1>
        
        <!-- Statistieken Cards -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-label">Totaal Films</div>
                <div class="stat-number"><?= htmlspecialchars($totalFilms) ?></div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Totaal Reviews</div>
                <div class="stat-number"><?= htmlspecialchars($totalReviews) ?></div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Gemiddelde Beoordeling</div>
                <div class="stat-number"><?= htmlspecialchars($gemiddeldeBeoordeling) ?>/10</div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Actieve Gebruikers</div>
                <div class="stat-number"><?= htmlspecialchars($totalUsers) ?></div>
            </div>
        </div>

        <!-- Films per Genre -->
        <div class="dashboard-section">
            <h2>🎬 Films per Genre</h2>
            <div class="genre-grid">
                <?php foreach ($genreData as $genre): ?>
                    <div class="genre-item">
                        <div class="genre-name"><?= htmlspecialchars($genre['genre']) ?></div>
                        <div class="genre-count"><?= htmlspecialchars($genre['aantal']) ?></div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- Reviews per Genre Grafiek -->
        <div class="dashboard-section">
            <h2>📈 Reviews per Genre</h2>
            <div class="chart-container">
                <canvas id="reviewsChart"></canvas>
            </div>
        </div>

        <!-- Twee kolommen: Top Films en Nieuwste Films -->
        <div class="two-column">
            <!-- Top 5 Best Beoordeelde Films -->
            <div class="dashboard-section">
                <h2>⭐ Top 5 Best Beoordeelde Films</h2>
                <ul class="top-films-list">
                    <?php foreach ($topFilms as $index => $film): ?>
                        <li>
                            <span>
                                <strong><?= $index + 1 ?>.</strong> 
                                <span class="film-title"><?= htmlspecialchars($film['titel']) ?></span>
                                <small>(<?= $film['aantal_reviews'] ?> reviews)</small>
                            </span>
                            <span class="film-rating"><?= htmlspecialchars($film['gem_beoordeling']) ?>/10</span>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>

            <!-- Nieuwste Films -->
            <div class="dashboard-section">
                <h2>🆕 Nieuwste Films</h2>
                <ul class="top-films-list">
                    <?php foreach ($nieuwsteFilms as $film): ?>
                        <li>
                            <span class="film-title"><?= htmlspecialchars($film['titel']) ?></span>
                            <span style="color: #666;">
                                <?= htmlspecialchars($film['releasejaar']) ?> • <?= htmlspecialchars($film['genre']) ?>
                            </span>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
    </div>

    <footer>
        <p>&copy; <?= date("Y") ?> Filmbeheer. Alle rechten voorbehouden.</p>
    </footer>

    <script>
        // Data voor de grafiek voorbereiden
        const genreLabels = <?= json_encode(array_column($reviewsPerGenre, 'genre')) ?>;
        const reviewCounts = <?= json_encode(array_column($reviewsPerGenre, 'aantal_reviews')) ?>;

        // Chart.js configuratie
        const ctx = document.getElementById('reviewsChart').getContext('2d');
        const reviewsChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: genreLabels,
                datasets: [{
                    label: 'Aantal Reviews',
                    data: reviewCounts,
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.7)',
                        'rgba(54, 162, 235, 0.7)',
                        'rgba(255, 206, 86, 0.7)',
                        'rgba(75, 192, 192, 0.7)',
                        'rgba(153, 102, 255, 0.7)',
                        'rgba(255, 159, 64, 0.7)',
                        'rgba(199, 199, 199, 0.7)',
                        'rgba(83, 102, 255, 0.7)',
                        'rgba(255, 99, 255, 0.7)',
                        'rgba(99, 255, 132, 0.7)',
                        'rgba(255, 159, 243, 0.7)',
                        'rgba(159, 255, 243, 0.7)'
                    ],
                    borderColor: [
                        'rgba(255, 99, 132, 1)',
                        'rgba(54, 162, 235, 1)',
                        'rgba(255, 206, 86, 1)',
                        'rgba(75, 192, 192, 1)',
                        'rgba(153, 102, 255, 1)',
                        'rgba(255, 159, 64, 1)',
                        'rgba(199, 199, 199, 1)',
                        'rgba(83, 102, 255, 1)',
                        'rgba(255, 99, 255, 1)',
                        'rgba(99, 255, 132, 1)',
                        'rgba(255, 159, 243, 1)',
                        'rgba(159, 255, 243, 1)'
                    ],
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    title: {
                        display: true,
                        text: 'Verdeling van Reviews over Genres',
                        font: {
                            size: 16
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            stepSize: 1
                        },
                        title: {
                            display: true,
                            text: 'Aantal Reviews'
                        }
                    },
                    x: {
                        title: {
                            display: true,
                            text: 'Genre'
                        }
                    }
                }
            }
        });
    </script>
</body>
</html>
