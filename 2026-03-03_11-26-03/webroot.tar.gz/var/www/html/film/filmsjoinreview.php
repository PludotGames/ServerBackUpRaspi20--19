<?php
include 'menu.php'; // Navigatiemenu
include 'db_connection.php'; // Verbind met de database

// Haal films met hun reviews op, gesorteerd op releasejaar (nieuwste eerst)
try {
    $query = "
        SELECT 
            films.titel AS film_titel,
            films.genre,
            films.releasejaar,
            films.duur,
            reviews.gebruikersnaam,
            reviews.beoordeling,
            reviews.commentaar
        FROM 
            films
        LEFT JOIN 
            reviews ON films.film_id = reviews.film_id
        ORDER BY 
            films.releasejaar DESC, films.titel ASC
    ";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $films_with_reviews = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "<p>Fout bij het ophalen van films en reviews: " . htmlspecialchars($e->getMessage()) . "</p>";
    die();
}
?>

<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Films met Reviews</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            text-align: center;
        }
        .table-container {
            width: 90%;
            margin: 20px auto;
            border: 1px solid #ddd;
            border-radius: 8px;
            background-color: #ffffff;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table th, table td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }
        table th {
            background-color: #f4f4f4;
        }
        table tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        table tr:nth-child(odd) {
            background-color: #ffffff;
        }
        table tr:hover {
            background-color: #f1f1f1;
        }
        h1 {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <h1>Films met Reviews</h1>
    <div class="table-container">
        <?php if (count($films_with_reviews) > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>Film Titel</th>
                        <th>Genre</th>
                        <th>Releasejaar</th>
                        <th>Duur (min)</th>
                        <th>Gebruikersnaam</th>
                        <th>Beoordeling</th>
                        <th>Commentaar</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($films_with_reviews as $row): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['film_titel']) ?></td>
                        <td><?= htmlspecialchars($row['genre']) ?></td>
                        <td><?= htmlspecialchars($row['releasejaar']) ?></td>
                        <td><?= htmlspecialchars($row['duur']) ?></td>
                        <td><?= htmlspecialchars($row['gebruikersnaam'] ?? 'Geen review') ?></td>
                        <td><?= htmlspecialchars($row['beoordeling'] ?? '-') ?></td>
                        <td><?= htmlspecialchars($row['commentaar'] ?? 'Geen commentaar') ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>Geen films of reviews gevonden in de database.</p>
        <?php endif; ?>
    </div>
</body>
</html>
