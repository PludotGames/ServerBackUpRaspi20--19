<?php
    include 'menu.php'; // Navigatiemenu
    include 'db_connection.php'; // Verbind met de database

    // Haal de top 10 films op basis van gemiddelde beoordeling
    try {
        $query = "
        SELECT
        films.titel AS film_titel,
        films.genre,
        films.releasejaar,
        films.duur,
        AVG(reviews.beoordeling) AS gemiddelde_beoordeling,
        COUNT(reviews.review_id) AS aantal_reviews
        FROM
        films
        INNER JOIN
        reviews ON films.film_id = reviews.film_id
        GROUP BY
        films.film_id
        ORDER BY
        films.duur DESC;
        ";
        $stmt = $conn->prepare($query);
        $stmt->execute();
        $top_10_films = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        echo "<p>Fout bij het ophalen van de top 10 films: " .
        htmlspecialchars($e->getMessage()) . "</p>";
        die();
    }
?>

<!DOCTYPE html>
<html lang="nl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>films duurtijd</title>
<style>
body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f4f4f4;
    text-align: center;
}
.table-container {
    width: 90%;
    margin: 20px auto;
    border: 1px solid #ddd;
    border-radius: 8px;
    background-color: #ffffff;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}
table {
    width: 100%;
    border-collapse: collapse;
}
table th, table td {
    padding: 10px;
    border: 1px solid #ddd;
    text-align: left;
}
table th {
    background-color: #f4f4f4;
}
table tr:nth-child(even) {
    background-color: #f9f9f9;
}
table tr:nth-child(odd) {
    background-color: #ffffff;
}
table tr:hover {
    background-color: #f1f1f1;
}
h1 {
    margin-top: 20px;
}
</style>
</head>
<body>
<h1>Films geordend aan de hand van duurtijd</h1>
<div class="table-container">
<?php if (count($top_10_films) > 0): ?>
<table>
<thead>
<tr>
<th>Film Titel</th>
<th>Genre</th>
<th>Releasejaar</th>
<th>Duur (min)</th>
<th>Gemiddelde Beoordeling</th>
<th>Aantal Reviews</th>
</tr>
</thead>
<tbody>
<?php foreach ($top_10_films as $film): ?>
<tr>
<td><?= htmlspecialchars($film['film_titel']) ?></td>
<td><?= htmlspecialchars($film['genre']) ?></td>
<td><?= htmlspecialchars($film['releasejaar']) ?></td>
<td><?= htmlspecialchars($film['duur']) ?></td>
<td><?= number_format($film['gemiddelde_beoordeling'],
                      1) ?></td>
                      <td><?= htmlspecialchars($film['aantal_reviews'])
                      ?></td>
                      </tr>
                      <?php endforeach; ?>
                      </tbody>
                      </table>
                      <?php else: ?>
                      <p>Geen films gevonden in de database.</p>
                      <?php endif; ?>
                      </div>
</body>
</html>
