<!DOCTYPE html>
<html lang="nl">
<head>
    <title>Overzicht van Clubs</title>
</head>
<body>

    <h2>Overzicht van Alle Clubs</h2>

    <?php
    // Databasegegevens
    $servername = "localhost";
    $username = "sport"; // Jouw gebruikersnaam
    $password = "sportpw"; // Jouw wachtwoord
    $dbname = "SportclubsDB"; // Jouw database naam

    // Verbinding maken met de database
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Controleer de verbinding
    if ($conn->connect_error) {
        die("<p class='error-msg'>Verbinding mislukt: " . $conn->connect_error . "</p>");
    }

    // SQL-query om alle clubs op te halen
    $sql = "SELECT * FROM clubs";
    $result = $conn->query($sql);

    // Controleer of er clubs zijn
    if ($result->num_rows > 0) {
        // Tabel om de clubs weer te geven
        echo "<table>";
        echo "<tr><th>Club ID</th><th>Naam</th><th>Locatie</th><th>Sportsoort</th><th>Oprichtingsjaar</th><th>Aantal Leden</th></tr>";

        // Loop door alle clubs en toon de gegevens in de tabel
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row['club_id'] . "</td>";
            echo "<td>" . $row['naam'] . "</td>";
            echo "<td>" . $row['locatie'] . "</td>";
            echo "<td>" . $row['sportsoort'] . "</td>";
            echo "<td>" . $row['oprichtingsjaar'] . "</td>";
            echo "<td>" . $row['aantal_leden'] . "</td>";
            echo "</tr>";
        }

        echo "</table>";
    } else {
        echo "<p class='error-msg'>Geen clubs gevonden.</p>";
    }

    // Sluit de verbinding
    $conn->close();
    ?>

</body>
</html>
