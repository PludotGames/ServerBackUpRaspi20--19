<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Settings
$host = "localhost";
$user = "logger";
$password = "paswoord";
$database = "temperatures";
$hours = 24;

// make connection to database
$connectdb = mysqli_connect($host, $user, $password, $database);

if (!$connectdb) {
    die("Database connection failed: " . mysqli_connect_error());
}

// sql command that selects all entries from current time and X hours backwards
$sql = "SELECT * FROM temperaturedata 
        WHERE dateandtime >= (NOW() - INTERVAL $hours HOUR)
        ORDER BY dateandtime DESC";

$temperatures = mysqli_query($connectdb, $sql);

if (!$temperatures) {
    die("Query failed: " . mysqli_error($connectdb));
}
header("location:TemperatuurLogger/index.php ")
?>
<html>
<head>
    <title>Klastemperatuur van Raspi25</title>
</head>
<body>
<h3>Temperatuur en vochtigheid - data</h3>
<br>
<table width="800" border="1" cellpadding="1" cellspacing="1" align="center">
<tr>
    <th>Date</th>
    <th>Sensor</th>
    <th>Temperature</th>
    <th>Humidity</th>
</tr>
<?php
while ($temperature = mysqli_fetch_assoc($temperatures)) {
    echo "<tr>";
    echo "<td>" . $temperature['dateandtime'] . "</td>";
    echo "<td>" . $temperature['sensor'] . "</td>";
    echo "<td>" . $temperature['temperature'] . "</td>";
    echo "<td>" . $temperature['humidity'] . "</td>";
    echo "</tr>";
}
?>
</table>
</body>
</html>
